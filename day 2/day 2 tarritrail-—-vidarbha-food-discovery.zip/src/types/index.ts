export type DietaryOption = 'Veg' | 'Non-Veg' | 'Veg & Non-Veg';

export type BudgetTier = 'Budget' | 'Moderate' | 'Premium';

export interface FoodListing {
  id: number;
  name: string;
  slug: string;
  city: string;
  category: string;
  speciality: string;
  description: string;
  address: string;
  phone: string;
  openingHours: string;
  priceMin: number;
  priceMax: number;
  budgetTier: BudgetTier;
  dietary: DietaryOption;
  rating: number;
  reviewCount: number;
  imageUrl: string;
  lat: number;
  lng: number;
  isVerified: boolean;
  isTrending: boolean;
  isHiddenGem: boolean;
  isFeatured: boolean;
  popularDishes: string[];
  createdAt: string;
}

export interface ReviewItem {
  id: number;
  listingId: number;
  listingName?: string;
  listingCity?: string;
  userId: number | null;
  authorName: string;
  rating: number;
  comment: string;
  imageUrl: string | null;
  createdAt: string;
}

export interface SubmissionItem {
  id: number;
  userId: number | null;
  submitterName: string;
  submitterEmail: string;
  name: string;
  city: string;
  category: string;
  speciality: string;
  description: string;
  address: string;
  phone: string;
  openingHours: string;
  priceMin: number;
  priceMax: number;
  dietary: DietaryOption;
  isHiddenGem: boolean;
  imageUrl: string;
  status: 'pending' | 'approved' | 'rejected';
  adminNote: string | null;
  createdAt: string;
}

export interface FoodStory {
  id: number;
  slug: string;
  title: string;
  subtitle: string;
  city: string;
  topic: string;
  readTime: string;
  author: string;
  publishedAt: string;
  imageUrl: string;
  excerpt: string;
  content: string[];
  recipeHighlights?: {
    dishName: string;
    prepTime: string;
    keyIngredients: string[];
    methodSummary: string;
  };
}

export interface UserProfile {
  id: number;
  name: string;
  email: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface AdminStats {
  totalListings: number;
  verifiedListings: number;
  demoListings: number;
  pendingSubmissions: number;
  totalReviews: number;
  totalUsers: number;
  citiesCovered: number;
}
