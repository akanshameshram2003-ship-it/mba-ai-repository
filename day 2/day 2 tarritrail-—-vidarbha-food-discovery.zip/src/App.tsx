/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import type { FoodListing, FoodStory, ReviewItem } from './types/index.ts';
import { AuthProvider } from './context/AuthContext.tsx';
import { Navbar, type AppPage } from './components/Navbar.tsx';
import { HomeView } from './components/HomeView.tsx';
import { DiscoverView, type DiscoverFilters } from './components/DiscoverView.tsx';
import { CitiesView } from './components/CitiesView.tsx';
import { StoriesView } from './components/StoriesView.tsx';
import { SubmitGemView } from './components/SubmitGemView.tsx';
import { SavedFavoritesView } from './components/SavedFavoritesView.tsx';
import { AdminDashboardView } from './components/AdminDashboardView.tsx';
import { ListingDetailModal } from './components/ListingDetailModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { Footer } from './components/Footer.tsx';

function TarriTrailApp() {
  const [page, setPage] = useState<AppPage>('home');
  const [listings, setListings] = useState<FoodListing[]>([]);
  const [stories, setStories] = useState<FoodStory[]>([]);
  const [recentReviews, setRecentReviews] = useState<ReviewItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [selectedListing, setSelectedListing] = useState<FoodListing | null>(null);
  const [selectedStory, setSelectedStory] = useState<FoodStory | null>(null);

  const [filters, setFilters] = useState<DiscoverFilters>({
    search: '',
    city: 'All',
    category: 'All',
    budget: 'All',
    minRating: 0,
    dietary: 'All',
    flag: 'All',
  });

  const loadAllData = useCallback(async () => {
    setLoadError(null);
    try {
      const [listingsRes, storiesRes, reviewsRes] = await Promise.all([
        fetch('/api/listings'),
        fetch('/api/stories'),
        fetch('/api/reviews/recent'),
      ]);
      if (!listingsRes.ok) throw new Error('Unable to load listings.');
      const [lData, sData, rData] = await Promise.all([
        listingsRes.json(),
        storiesRes.ok ? storiesRes.json() : [],
        reviewsRes.ok ? reviewsRes.json() : [],
      ]);
      setListings(Array.isArray(lData) ? lData : []);
      setStories(Array.isArray(sData) ? sData : []);
      setRecentReviews(Array.isArray(rData) ? rData : []);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Unable to connect to server.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadAllData();
  }, [loadAllData]);

  const scrollTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const handleNavigate = (nextPage: AppPage) => {
    if (nextPage !== 'stories') {
      setSelectedStory(null);
    }
    setPage(nextPage);
    scrollTop();
  };

  const handleSelectCity = (cityName: string) => {
    setFilters({
      search: '',
      city: cityName,
      category: 'All',
      budget: 'All',
      minRating: 0,
      dietary: 'All',
      flag: 'All',
    });
    setPage('discover');
    scrollTop();
  };

  const handleSelectCategory = (categoryName: string) => {
    setFilters({
      search: '',
      city: 'All',
      category: categoryName,
      budget: 'All',
      minRating: 0,
      dietary: 'All',
      flag: 'All',
    });
    setPage('discover');
    scrollTop();
  };

  const handleSearchSubmit = (query: string) => {
    setFilters({
      search: query,
      city: 'All',
      category: 'All',
      budget: 'All',
      minRating: 0,
      dietary: 'All',
      flag: 'All',
    });
    setPage('discover');
    scrollTop();
  };

  const handleListingUpdated = (updated: FoodListing) => {
    setListings((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
    void fetch('/api/reviews/recent')
      .then((r) => (r.ok ? r.json() : []))
      .then((rData) => {
        if (Array.isArray(rData)) setRecentReviews(rData);
      });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#1F1510]">
      <Navbar currentPage={page} onNavigate={handleNavigate} />

      <main className="flex-1">
        {loadError && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
            <div className="bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] px-4 py-3 rounded-xl text-sm flex items-center justify-between gap-4">
              <span>{loadError}</span>
              <button
                type="button"
                onClick={() => void loadAllData()}
                className="px-3 py-1.5 text-xs font-semibold bg-white border border-[#FECACA] rounded-lg"
              >
                Retry
              </button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="h-72 rounded-xl bg-white border border-[#E7E0D8] animate-pulse"
              />
            ))}
          </div>
        ) : page === 'home' ? (
          <HomeView
            listings={listings}
            stories={stories}
            recentReviews={recentReviews}
            onSearchSubmit={handleSearchSubmit}
            onSelectCity={handleSelectCity}
            onSelectCategory={handleSelectCategory}
            onSelectListing={setSelectedListing}
            onOpenStories={(story) => {
              setSelectedStory(story ?? null);
              setPage('stories');
              scrollTop();
            }}
            onOpenSubmit={() => handleNavigate('submit')}
          />
        ) : page === 'discover' ? (
          <DiscoverView
            listings={listings}
            filters={filters}
            onFiltersChange={setFilters}
            onSelectListing={setSelectedListing}
          />
        ) : page === 'cities' ? (
          <CitiesView listings={listings} onSelectCity={handleSelectCity} />
        ) : page === 'stories' ? (
          <StoriesView
            stories={stories}
            initialStory={selectedStory}
            onExploreCity={handleSelectCity}
          />
        ) : page === 'submit' ? (
          <SubmitGemView onSuccessNavigateFavorites={() => handleNavigate('favorites')} />
        ) : page === 'favorites' ? (
          <SavedFavoritesView
            onSelectListing={setSelectedListing}
            onExplore={() => handleNavigate('discover')}
          />
        ) : (
          <AdminDashboardView onDataChanged={() => void loadAllData()} />
        )}
      </main>

      <Footer onNavigate={handleNavigate} onSelectCity={handleSelectCity} />

      <ListingDetailModal
        listing={selectedListing}
        onClose={() => setSelectedListing(null)}
        onListingUpdated={handleListingUpdated}
      />

      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <TarriTrailApp />
    </AuthProvider>
  );
}
