export interface CityMeta {
  name: string;
  tagline: string;
  knownFor: string;
  famousMarket: string;
  lat: number;
  lng: number;
  heroImage: string;
  description: string;
}

export const VIDARBHA_CITIES: CityMeta[] = [
  {
    name: 'Nagpur',
    tagline: 'Orange Capital & Saoji Heartland',
    knownFor: 'Tarri Poha, Saoji Mutton, Santra Barfi',
    famousMarket: 'Itwari & Sitabuldi Food Lanes',
    lat: 21.1458,
    lng: 79.0882,
    heroImage: '/src/assets/images/dish_tarri_poha_1795245658651.jpg',
    description:
      'From 6 AM steaming plates of spicy Tarri Poha to late-evening copper-handi Saoji feasts and citrus-sweet Santra Barfi, Nagpur anchors Vidarbha’s culinary identity.'
  },
  {
    name: 'Amravati',
    tagline: 'West Vidarbha’s Street & Café Hub',
    knownFor: 'Gola Bhat, Spicy Misal, Student Cafés',
    famousMarket: 'Rajkamal Square & Camp Road',
    lat: 20.932,
    lng: 77.7523,
    heroImage: '/src/assets/images/story_food_market_1795245659189.jpg',
    description:
      'Bustling college crowds keep Amravati’s chaat carts, misal joints, and modern hangout cafés humming from morning breakfast through midnight snacks.'
  },
  {
    name: 'Wardha',
    tagline: 'Earthy Kitchens & Traditional Thalis',
    knownFor: 'Jhunka Bhakri, Pithla, Garlic Thecha',
    famousMarket: 'Bajaj Square & Sevagram Road',
    lat: 20.7453,
    lng: 78.6022,
    heroImage: '/src/assets/images/dish_patodi_bhakri_1795245658746.jpg',
    description:
      'Rooted in agrarian simplicity, Wardha celebrates hand-patted jowar bhakri, slow-simmered besan pithla, and crisp morning moong dal vadas.'
  },
  {
    name: 'Bhandara',
    tagline: 'Lake District & Rice-Bowl Delicacies',
    knownFor: 'Patodi Rassa, Wada Bhat, River Fish Curry',
    famousMarket: 'Gandhi Chowk & Main Bazaar',
    lat: 21.1777,
    lng: 79.657,
    heroImage: '/src/assets/images/dish_patodi_bhakri_1795245658746.jpg',
    description:
      'Surrounded by fertile paddy fields and lakes, Bhandara pairs fragrant local rice dishes with fiery patodi rassa and roasted spice masalas.'
  },
  {
    name: 'Gondia',
    tagline: 'Rice City & Khapri Specialities',
    knownFor: 'Khapri Puranpoli, Kachori, Bamboo Curries',
    famousMarket: 'Jaistambh Chowk & Rail Toli',
    lat: 21.4624,
    lng: 80.221,
    heroImage: '/src/assets/images/story_food_market_1795245659189.jpg',
    description:
      'At the eastern gateway of Vidarbha, Gondia blends classic Maharashtrian snacks with central Indian spice traditions and festive sweets.'
  },
  {
    name: 'Chandrapur',
    tagline: 'Tiger Gateway & Fiery Spice Pots',
    knownFor: 'Saoji Chicken, Kanda Bhajji, Bhakri Meals',
    famousMarket: 'Gandhi Chowk & Jatpura Gate',
    lat: 19.9615,
    lng: 79.2961,
    heroImage: '/src/assets/images/dish_saoji_curry_1795245657802.jpg',
    description:
      'After safari mornings near Tadoba, travellers and locals gather in Chandrapur for deeply spiced rassa curries and crisp evening pakodas.'
  },
  {
    name: 'Gadchiroli',
    tagline: 'Forest Produce & Millet Heritage',
    knownFor: 'Ragi Bhakri, Bamboo Shoot Sabzi, Mahua Laddoo',
    famousMarket: 'Indira Gandhi Chowk & Complex Market',
    lat: 20.1809,
    lng: 80.0015,
    heroImage: '/src/assets/images/dish_patodi_bhakri_1795245658746.jpg',
    description:
      'Rich in seasonal forest ingredients, Gadchiroli highlights nutritious millet flatbreads, wild honey sweets, and rustic slow-cooked curries.'
  },
  {
    name: 'Yavatmal',
    tagline: 'Cotton Belt & Highway Comfort Food',
    knownFor: 'Sev Bhaji, Besan Poli, Spiced Mattha',
    famousMarket: 'Azad Maidan & Datta Chowk',
    lat: 20.3899,
    lng: 78.1307,
    heroImage: '/src/assets/images/dish_saoji_curry_1795245657802.jpg',
    description:
      'Known for generous thalis, smoky dhaba-style sev bhaji, and refreshing spiced buttermilk tailored for warm Vidarbha afternoons.'
  },
  {
    name: 'Akola',
    tagline: 'Grain Market & Morning Farsan Hub',
    knownFor: 'Dal Kachori, Bedai Sabzi, Khari & Chaat',
    famousMarket: 'Tilak Road & Gandhi Road',
    lat: 20.7002,
    lng: 77.0082,
    heroImage: '/src/assets/images/dish_tarri_poha_1795245658651.jpg',
    description:
      'Akola’s historic trading quarters wake up to flaky lentil kachoris, tangy tamarind chutneys, and beloved local sweet marts.'
  },
  {
    name: 'Washim',
    tagline: 'Temple Town & Heirloom Recipes',
    knownFor: 'Puran Poli, Shengdana Chutney, Pithla',
    famousMarket: 'Patni Chowk & Risod Naka',
    lat: 20.1119,
    lng: 77.1312,
    heroImage: '/src/assets/images/dish_santra_barfi_1795245658533.jpg',
    description:
      'A serene culinary stopover famous for festive sweet flatbreads, roasted peanut chutneys, and affordable family-run bhojanalayas.'
  },
  {
    name: 'Buldhana',
    tagline: 'Lonar Crater & Gateway Flavours',
    knownFor: 'Bhajni Vada, Masala Khichdi, Malai Pedha',
    famousMarket: 'Jaistambh Chowk & Chikhli Road',
    lat: 20.5293,
    lng: 76.1842,
    heroImage: '/src/assets/images/dish_santra_barfi_1795245658533.jpg',
    description:
      'Bridging western Vidarbha with Lonar’s heritage trail, Buldhana serves comforting spiced khichdi, crispy multigrain vadas, and rich dairy sweets.'
  }
];

export const FOOD_CATEGORIES: {
  name: string;
  subtitle: string;
  accent: string;
}[] = [
  { name: 'Street Food', subtitle: 'Tarri poha, kachori & evening chaat lanes', accent: 'Saffron Trail' },
  { name: 'Traditional Vidarbha Food', subtitle: 'Saoji masalas, patodi rassa & jhunka', accent: 'Heritage Kitchen' },
  { name: 'Restaurants', subtitle: 'Family dining halls & regional thalis', accent: 'Seated Dining' },
  { name: 'Cafés', subtitle: 'Specialty brews, snacks & student hangouts', accent: 'Modern Brews' },
  { name: 'Fast Food', subtitle: 'Crispy rolls, burgers & quick bites', accent: 'Quick Serve' },
  { name: 'Maharashtrian Food', subtitle: 'Puran poli, misal, sabudana & thalipeeth', accent: 'Classic State' },
  { name: 'Sweets and Desserts', subtitle: 'Santra barfi, malai pedha & jalebi', accent: 'Mithai Craft' },
  { name: 'Breakfast Spots', subtitle: 'Early-morning poha, idli & chai stalls', accent: 'Sunrise Picks' },
  { name: 'Budget-Friendly Food', subtitle: 'Hearty meals & snacks under ₹150', accent: 'Pocket Friendly' },
  { name: 'Non-Vegetarian Specialities', subtitle: 'Copper-handi Saoji mutton & chicken', accent: 'Spice Craft' }
];
