import React, { useState } from 'react';
import { CheckCircle2, ImagePlus, Sparkles } from 'lucide-react';
import { FOOD_CATEGORIES, VIDARBHA_CITIES } from '../data/vidarbhaMeta.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { SafeImage } from './SafeImage.tsx';

interface SubmitGemViewProps {
  onSuccessNavigateFavorites: () => void;
}

export function SubmitGemView({ onSuccessNavigateFavorites }: SubmitGemViewProps) {
  const { user, authFetch, openAuthModal } = useAuth();

  const [name, setName] = useState('');
  const [city, setCity] = useState('Nagpur');
  const [category, setCategory] = useState('Street Food');
  const [speciality, setSpeciality] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [openingHours, setOpeningHours] = useState('7:00 AM – 10:00 PM');
  const [priceMin, setPriceMin] = useState('50');
  const [priceMax, setPriceMax] = useState('200');
  const [dietary, setDietary] = useState<'Veg' | 'Non-Veg' | 'Veg & Non-Veg'>('Veg');
  const [isHiddenGem, setIsHiddenGem] = useState(true);
  const [imageUrl, setImageUrl] = useState('/src/assets/images/dish_tarri_poha_1795245658651.jpg');

  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedName, setSubmittedName] = useState<string | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!user) {
      openAuthModal();
      return;
    }

    setError(null);
    setUploading(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('Could not read file.'));
        reader.readAsDataURL(file);
      });

      const res = await authFetch('/api/upload', {
        method: 'POST',
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed.');
      setImageUrl(data.imageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to upload photo.');
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }

    setError(null);
    setSubmitting(true);
    try {
      const res = await authFetch('/api/submissions', {
        method: 'POST',
        body: JSON.stringify({
          name,
          city,
          category,
          speciality,
          description,
          address,
          phone: phone || 'Not provided',
          openingHours,
          priceMin: Number(priceMin),
          priceMax: Number(priceMax),
          dietary,
          isHiddenGem,
          imageUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Submission failed.');

      setSubmittedName(data.name);
      setName('');
      setSpeciality('');
      setDescription('');
      setAddress('');
      setPhone('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not submit recommendation.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-[#B91C1C]">
          Community Recommendations
        </p>
        <h1 className="mt-1 font-display text-3xl sm:text-4xl font-bold text-[#1F1510]">
          Recommend a Food Place or Hidden Gem
        </h1>
        <p className="mt-2 text-sm sm:text-base text-[#5C4B42] max-w-2xl">
          Know a beloved street stall in Akola, a secret Saoji bhojanalay in Chandrapur, or a
          cozy café in Amravati? Submit it for admin verification and publishing.
        </p>
      </div>

      {!user && (
        <div className="bg-[#FFFBEB] border border-[#FDE68A] rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-[#92400E]">
              Sign in required to submit recommendations
            </p>
            <p className="text-xs text-[#92400E]/90 mt-0.5">
              Create a free account so you can upload dish photos and track approval status.
            </p>
          </div>
          <button
            type="button"
            onClick={openAuthModal}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg whitespace-nowrap shrink-0"
          >
            Sign In / Join Free
          </button>
        </div>
      )}

      {submittedName && (
        <div className="bg-[#F0FDF4] border border-[#BBF7D0] rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#15803D] shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-[#166534]">
                Recommendation submitted: {submittedName}
              </p>
              <p className="text-xs text-[#166534]/90 mt-0.5">
                Your entry is queued in the Admin Dashboard for review and verification.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onSuccessNavigateFavorites}
            className="px-3.5 py-2 text-xs font-semibold text-[#166534] bg-white border border-[#BBF7D0] rounded-lg hover:bg-[#DCFCE7] whitespace-nowrap shrink-0"
          >
            Track Submission
          </button>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="bg-white border border-[#E7E0D8] rounded-xl p-6 sm:p-8 space-y-6"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="sm:col-span-2">
            <label htmlFor="sub-name" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Restaurant or Food Stall Name *
            </label>
            <input
              id="sub-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Gajanan Morning Tarri Poha"
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="sub-city" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Vidarbha City *
            </label>
            <select
              id="sub-city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            >
              {VIDARBHA_CITIES.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="sub-cat" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Food Category *
            </label>
            <select
              id="sub-cat"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            >
              {FOOD_CATEGORIES.map((cat) => (
                <option key={cat.name} value={cat.name}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="sub-spec" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Famous Dish / Food Speciality *
            </label>
            <input
              id="sub-spec"
              type="text"
              required
              value={speciality}
              onChange={(e) => setSpeciality(e.target.value)}
              placeholder="e.g. Extra spicy kala-chana tarri with crispy samosa and masala chai"
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="sub-addr" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Location & Landmark Address *
            </label>
            <input
              id="sub-addr"
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Street, square or landmark name"
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="sub-hours" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Opening Hours
            </label>
            <input
              id="sub-hours"
              type="text"
              value={openingHours}
              onChange={(e) => setOpeningHours(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="sub-phone" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Contact Phone (Optional)
            </label>
            <input
              id="sub-phone"
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 ..."
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="sub-min" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Min Price (₹)
            </label>
            <input
              id="sub-min"
              type="number"
              min={10}
              value={priceMin}
              onChange={(e) => setPriceMin(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="sub-max" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Max Price for Two (₹)
            </label>
            <input
              id="sub-max"
              type="number"
              min={20}
              value={priceMax}
              onChange={(e) => setPriceMax(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="sub-diet" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Dietary Options
            </label>
            <select
              id="sub-diet"
              value={dietary}
              onChange={(e) => setDietary(e.target.value as 'Veg' | 'Non-Veg' | 'Veg & Non-Veg')}
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            >
              <option value="Veg">Pure Veg</option>
              <option value="Non-Veg">Non-Veg</option>
              <option value="Veg & Non-Veg">Veg & Non-Veg</option>
            </select>
          </div>

          <div className="flex items-end pb-2">
            <label className="inline-flex items-center gap-2.5 text-sm font-medium text-[#1F1510] cursor-pointer">
              <input
                type="checkbox"
                checked={isHiddenGem}
                onChange={(e) => setIsHiddenGem(e.target.checked)}
                className="w-4 h-4 accent-[#E85D04] rounded"
              />
              <Sparkles className="w-4 h-4 text-[#E85D04]" aria-hidden="true" />
              <span>Suggest as a Hidden Food Gem</span>
            </label>
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="sub-desc" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Why do locals love this spot?
            </label>
            <textarea
              id="sub-desc"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the flavours, history, best time to visit, or seating..."
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div className="sm:col-span-2 pt-2 border-t border-[#F0EAE2]">
            <span className="block text-xs font-semibold text-[#1F1510] mb-2">
              Food Photograph
            </span>
            <div className="flex flex-wrap items-center gap-4">
              <div className="w-28 aspect-[4/3] rounded-lg overflow-hidden border border-[#E7E0D8] bg-[#F3ECE4]">
                <SafeImage
                  src={imageUrl}
                  alt="Food submission preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-[#D8CEC3] bg-[#FAF8F5] hover:bg-[#F3ECE4] text-xs font-semibold text-[#1F1510] cursor-pointer transition-colors">
                <ImagePlus className="w-4 h-4 text-[#E85D04]" aria-hidden="true" />
                <span>{uploading ? 'Uploading...' : 'Upload Dish Photo'}</span>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFileUpload}
                  className="sr-only"
                />
              </label>
            </div>
          </div>
        </div>

        {error && (
          <p className="text-xs font-medium text-[#B91C1C] bg-[#FEF2F2] border border-[#FECACA] px-3 py-2 rounded-lg">
            {error}
          </p>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={submitting || uploading}
            className="px-6 py-2.5 text-sm font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] disabled:opacity-60 rounded-lg transition-colors"
          >
            {submitting ? 'Submitting...' : 'Submit for Verification'}
          </button>
        </div>
      </form>
    </div>
  );
}
