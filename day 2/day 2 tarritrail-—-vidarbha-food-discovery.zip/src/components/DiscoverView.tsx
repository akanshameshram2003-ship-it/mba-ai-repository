import { useMemo } from 'react';
import { ExternalLink, MapPin, RotateCcw, Search } from 'lucide-react';
import type { FoodListing } from '../types/index.ts';
import { FOOD_CATEGORIES, VIDARBHA_CITIES } from '../data/vidarbhaMeta.ts';
import { ListingCard } from './ListingCard.tsx';
import { SafeImage } from './SafeImage.tsx';

export interface DiscoverFilters {
  search: string;
  city: string;
  category: string;
  budget: string;
  minRating: number;
  dietary: string;
  flag: string;
}

interface DiscoverViewProps {
  listings: FoodListing[];
  filters: DiscoverFilters;
  onFiltersChange: (next: DiscoverFilters) => void;
  onSelectListing: (listing: FoodListing) => void;
}

export function DiscoverView({
  listings,
  filters,
  onFiltersChange,
  onSelectListing,
}: DiscoverViewProps) {
  const activeCityMeta = useMemo(
    () => VIDARBHA_CITIES.find((c) => c.name === filters.city) || null,
    [filters.city]
  );

  const filtered = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    return listings.filter((item) => {
      if (filters.city !== 'All' && item.city !== filters.city) return false;
      if (filters.category !== 'All' && item.category !== filters.category) return false;
      if (filters.budget !== 'All' && item.budgetTier !== filters.budget) return false;
      if (filters.minRating > 0 && item.rating < filters.minRating) return false;
      if (filters.dietary === 'Veg' && item.dietary === 'Non-Veg') return false;
      if (filters.dietary === 'Non-Veg' && item.dietary === 'Veg') return false;
      if (filters.flag === 'hidden' && !item.isHiddenGem) return false;
      if (filters.flag === 'trending' && !item.isTrending) return false;
      if (filters.flag === 'featured' && !item.isFeatured) return false;

      if (q) {
        const haystack = [
          item.name,
          item.city,
          item.category,
          item.speciality,
          item.address,
          item.popularDishes.join(' '),
        ]
          .join(' ')
          .toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [listings, filters]);

  const resetFilters = () => {
    onFiltersChange({
      search: '',
      city: 'All',
      category: 'All',
      budget: 'All',
      minRating: 0,
      dietary: 'All',
      flag: 'All',
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Dedicated City Food Discovery Header when a specific city is active */}
      {activeCityMeta ? (
        <section className="bg-white border border-[#E7E0D8] rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          <div className="lg:col-span-5 h-56 lg:h-auto bg-[#F3ECE4]">
            <SafeImage
              src={activeCityMeta.heroImage}
              alt={`${activeCityMeta.name} regional cuisine`}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-semibold text-[#B91C1C]">
                  City Food Guide · Vidarbha
                </span>
                <button
                  type="button"
                  onClick={() => onFiltersChange({ ...filters, city: 'All' })}
                  className="text-[#6B5A50] hover:text-[#1F1510] underline"
                >
                  View All 11 Cities
                </button>
              </div>
              <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-[#1F1510]">
                {activeCityMeta.name} Food Discovery
              </h1>
              <p className="mt-1 text-sm font-medium text-[#E85D04]">{activeCityMeta.tagline}</p>
              <p className="mt-3 text-sm text-[#5C4B42] leading-relaxed">
                {activeCityMeta.description}
              </p>
            </div>

            <div className="pt-4 border-t border-[#F0EAE2] flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="space-y-1 text-[#5C4B42]">
                <div>
                  <strong className="text-[#1F1510]">Known for:</strong> {activeCityMeta.knownFor}
                </div>
                <div>
                  <strong className="text-[#1F1510]">Food hubs:</strong> {activeCityMeta.famousMarket}
                </div>
              </div>

              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                  `${activeCityMeta.name}, Vidarbha, Maharashtra`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-lg bg-[#1F1510] text-white font-semibold inline-flex items-center gap-1.5 hover:bg-[#38261D] transition-colors whitespace-nowrap shrink-0"
              >
                <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
                Open {activeCityMeta.name} Map
                <ExternalLink className="w-3 h-3" aria-hidden="true" />
              </a>
            </div>
          </div>
        </section>
      ) : (
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1510]">
            Discover Vidarbha Food Places
          </h1>
          <p className="mt-2 text-sm sm:text-base text-[#5C4B42] max-w-2xl">
            Filter across all 11 Vidarbha cities, 10 culinary categories, budget tiers, ratings,
            and dietary preferences.
          </p>
        </div>
      )}

      {/* Filter Bar */}
      <section
        aria-label="Food discovery filters"
        className="bg-white border border-[#E7E0D8] rounded-xl p-4 sm:p-5 space-y-4"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="lg:col-span-2 relative">
            <Search
              className="w-4 h-4 text-[#6B5A50] absolute left-3 top-1/2 -translate-y-1/2"
              aria-hidden="true"
            />
            <input
              type="search"
              value={filters.search}
              onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
              placeholder="Search dish, stall, area..."
              aria-label="Search food places"
              className="w-full pl-9 pr-3 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <select
            aria-label="Filter by city"
            value={filters.city}
            onChange={(e) => onFiltersChange({ ...filters, city: e.target.value })}
            className="px-3 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
          >
            <option value="All">All 11 Cities</option>
            {VIDARBHA_CITIES.map((c) => (
              <option key={c.name} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by category"
            value={filters.category}
            onChange={(e) => onFiltersChange({ ...filters, category: e.target.value })}
            className="px-3 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
          >
            <option value="All">All Categories</option>
            {FOOD_CATEGORIES.map((cat) => (
              <option key={cat.name} value={cat.name}>
                {cat.name}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by budget"
            value={filters.budget}
            onChange={(e) => onFiltersChange({ ...filters, budget: e.target.value })}
            className="px-3 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
          >
            <option value="All">Any Budget</option>
            <option value="Budget">Budget (Under ₹180)</option>
            <option value="Moderate">Moderate (₹180–₹450)</option>
            <option value="Premium">Premium (₹450+)</option>
          </select>

          <select
            aria-label="Filter by minimum rating"
            value={String(filters.minRating)}
            onChange={(e) => onFiltersChange({ ...filters, minRating: Number(e.target.value) })}
            className="px-3 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
          >
            <option value="0">Any Rating</option>
            <option value="4">4.0+ Stars</option>
            <option value="4.5">4.5+ Stars</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#F0EAE2]">
          <div className="flex flex-wrap items-center gap-2">
            {/* Dietary Segmented Control */}
            <div className="inline-flex p-1 bg-[#EFE7DD] rounded-lg gap-1">
              {(['All', 'Veg', 'Non-Veg'] as const).map((diet) => (
                <button
                  key={diet}
                  type="button"
                  onClick={() => onFiltersChange({ ...filters, dietary: diet })}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    filters.dietary === diet
                      ? 'bg-white text-[#1F1510] shadow-xs'
                      : 'text-[#5C4B42] hover:text-[#1F1510]'
                  }`}
                >
                  {diet === 'All' ? 'All Dietary' : diet}
                </button>
              ))}
            </div>

            {/* Collection Filter */}
            <div className="inline-flex p-1 bg-[#EFE7DD] rounded-lg gap-1">
              {(
                [
                  { id: 'All', label: 'All Spots' },
                  { id: 'trending', label: 'Trending' },
                  { id: 'hidden', label: 'Hidden Gems' },
                  { id: 'featured', label: 'Featured' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => onFiltersChange({ ...filters, flag: f.id })}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    filters.flag === f.id
                      ? 'bg-white text-[#1F1510] shadow-xs'
                      : 'text-[#5C4B42] hover:text-[#1F1510]'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-[#6B5A50]">
            <span className="tabular-nums font-medium">
              Showing {filtered.length} of {listings.length} places
            </span>
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1.5 font-semibold text-[#E85D04] hover:underline"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              Reset
            </button>
          </div>
        </div>
      </section>

      {/* Results Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-[#E7E0D8] rounded-xl p-10 text-center space-y-3">
          <h2 className="font-display text-xl font-bold text-[#1F1510]">
            No matching Vidarbha spots found
          </h2>
          <p className="text-sm text-[#6B5A50] max-w-md mx-auto">
            Try clearing one of your active filters or switching to another Vidarbha district.
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg transition-colors"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => (
            <ListingCard key={item.id} listing={item} onSelect={onSelectListing} />
          ))}
        </div>
      )}
    </div>
  );
}
