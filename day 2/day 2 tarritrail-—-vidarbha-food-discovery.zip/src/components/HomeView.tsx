import React, { useMemo, useState } from 'react';
import { ArrowRight, MapPin, Search, Star } from 'lucide-react';
import type { FoodListing, FoodStory, ReviewItem } from '../types/index.ts';
import { FOOD_CATEGORIES, VIDARBHA_CITIES } from '../data/vidarbhaMeta.ts';
import { ListingCard } from './ListingCard.tsx';
import { SafeImage } from './SafeImage.tsx';

interface HomeViewProps {
  listings: FoodListing[];
  stories: FoodStory[];
  recentReviews: ReviewItem[];
  onSearchSubmit: (query: string) => void;
  onSelectCity: (city: string) => void;
  onSelectCategory: (category: string) => void;
  onSelectListing: (listing: FoodListing) => void;
  onOpenStories: (story?: FoodStory) => void;
  onOpenSubmit: () => void;
}

type DiscoveryTab = 'trending' | 'featured' | 'hidden' | 'recent';

export function HomeView({
  listings,
  stories,
  recentReviews,
  onSearchSubmit,
  onSelectCity,
  onSelectCategory,
  onSelectListing,
  onOpenStories,
  onOpenSubmit,
}: HomeViewProps) {
  const [heroSearch, setHeroSearch] = useState('');
  const [activeTab, setActiveTab] = useState<DiscoveryTab>('trending');

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit(heroSearch.trim());
  };

  const tabListings = useMemo(() => {
    if (activeTab === 'trending') {
      return listings.filter((l) => l.isTrending).slice(0, 6);
    }
    if (activeTab === 'featured') {
      return listings.filter((l) => l.isFeatured).slice(0, 6);
    }
    if (activeTab === 'hidden') {
      return listings.filter((l) => l.isHiddenGem).slice(0, 6);
    }
    return [...listings].sort((a, b) => b.id - a.id).slice(0, 6);
  }, [listings, activeTab]);

  const popularDishesShowcase = [
    {
      name: 'Tarri Poha',
      city: 'Nagpur',
      note: 'Steaming flattened rice topped with fiery kala-chana tarri & sev',
      image: '/src/assets/images/dish_tarri_poha_1795245658651.jpg',
    },
    {
      name: 'Saoji Masala Handi',
      city: 'Nagpur & Chandrapur',
      note: '24-spice stone-ground gravy simmered in copper pots',
      image: '/src/assets/images/dish_saoji_curry_1795245657802.jpg',
    },
    {
      name: 'Patodi Rassa & Bhakri',
      city: 'Wardha & Bhandara',
      note: 'Steamed besan diamonds in spiced crimson curry with jowar bhakri',
      image: '/src/assets/images/dish_patodi_bhakri_1795245658746.jpg',
    },
    {
      name: 'Nagpur Santra Barfi',
      city: 'Nagpur',
      note: 'Slow-reduced khoya fudge infused with fresh mandarin citrus',
      image: '/src/assets/images/dish_santra_barfi_1795245658533.jpg',
    },
  ];

  return (
    <div className="space-y-16 sm:space-y-20 pb-16">
      {/* 1. Hero Section */}
      <section className="pt-8 sm:pt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-between py-2">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#B91C1C]">
                  Vidarbha Culinary Discovery Guide · 11 Districts
                </p>
                <h1
                  className="mt-3 font-display font-bold text-[#1F1510] tracking-tight leading-[1.08]"
                  style={{ fontSize: 'clamp(2.25rem, 4vw, 3.65rem)', textWrap: 'balance' }}
                >
                  Explore Vidarbha, One Bite at a Time.
                </h1>
                <p className="mt-4 text-base sm:text-lg text-[#5C4B42] max-w-xl leading-relaxed">
                  From 6 AM Tarri Poha stalls in Nagpur and Rajkamal street chaat in Amravati to
                  wood-fired Jhunka Bhakri in Wardha—find authentic kitchens across every corner of
                  eastern Maharashtra.
                </p>

                <form
                  onSubmit={handleHeroSearch}
                  className="mt-7 flex flex-col sm:flex-row gap-2.5 max-w-xl"
                >
                  <div className="relative flex-1">
                    <Search
                      className="w-4 h-4 text-[#6B5A50] absolute left-3.5 top-1/2 -translate-y-1/2"
                      aria-hidden="true"
                    />
                    <input
                      type="search"
                      value={heroSearch}
                      onChange={(e) => setHeroSearch(e.target.value)}
                      placeholder="Search Tarri Poha, Saoji, Amravati, Café..."
                      aria-label="Search food, restaurants, dishes or cities"
                      className="w-full pl-10 pr-4 py-3 text-sm bg-white border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 text-sm font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    Explore Food
                  </button>
                </form>

                <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-[#6B5A50]">
                  <span className="font-semibold text-[#1F1510]">Quick searches:</span>
                  {['Tarri Poha', 'Saoji', 'Nagpur', 'Patodi', 'Santra Barfi'].map((term) => (
                    <button
                      key={term}
                      type="button"
                      onClick={() => onSearchSubmit(term)}
                      className="hover:text-[#E85D04] underline underline-offset-4 decoration-[#D8CEC3] transition-colors"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>

              {/* Clean 4-column regional pulse row */}
              <div className="mt-8 pt-6 border-t border-[#E7E0D8] grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <div className="font-display text-2xl font-bold text-[#1F1510] tabular-nums">
                    11
                  </div>
                  <div className="text-xs text-[#6B5A50]">Vidarbha Cities</div>
                </div>
                <div>
                  <div className="font-display text-2xl font-bold text-[#1F1510] tabular-nums">
                    {listings.length}
                  </div>
                  <div className="text-xs text-[#6B5A50]">Curated Spots</div>
                </div>
                <div>
                  <div className="font-display text-2xl font-bold text-[#1F1510] tabular-nums">
                    10
                  </div>
                  <div className="text-xs text-[#6B5A50]">Food Categories</div>
                </div>
                <div>
                  <div className="font-display text-2xl font-bold text-[#1F1510] tabular-nums">
                    {stories.length}
                  </div>
                  <div className="text-xs text-[#6B5A50]">Food Stories</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="h-72 sm:h-96 lg:h-full rounded-xl overflow-hidden border border-[#E7E0D8] relative">
                <SafeImage
                  src="/src/assets/images/hero_vidarbha_feast_1795245658502.jpg"
                  alt="Authentic Vidarbha feast featuring Saoji curry, Tarri Poha, Jowar Bhakri, and Nagpur oranges"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white flex items-end justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium text-[#FDBA74]">
                      Featured Regional Spread
                    </p>
                    <p className="font-display text-lg font-semibold">
                      Saoji Handi, Tarri Poha & Jowar Bhakri
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenSubmit}
                    className="px-3.5 py-2 text-xs font-semibold bg-white/95 text-[#1F1510] hover:bg-white rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    Suggest a Spot
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Explore by City (All 11 Vidarbha Cities) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1F1510]">
              Explore by Vidarbha City
            </h2>
            <p className="mt-1 text-sm text-[#5C4B42]">
              Select any of the 11 districts to browse local food lanes, specialities, and directions.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
          {VIDARBHA_CITIES.map((city) => {
            const count = listings.filter((l) => l.city === city.name).length;
            return (
              <button
                key={city.name}
                type="button"
                onClick={() => onSelectCity(city.name)}
                className="group text-left bg-white border border-[#E7E0D8] hover:border-[#E85D04] rounded-xl p-4 transition-colors flex flex-col justify-between gap-2"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-display text-lg font-bold text-[#1F1510] group-hover:text-[#E85D04] transition-colors">
                      {city.name}
                    </span>
                    <span className="text-xs font-mono tabular-nums text-[#6B5A50]">
                      {count} {count === 1 ? 'spot' : 'spots'}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-[#6B5A50] line-clamp-1">{city.knownFor}</p>
                </div>
                <span className="text-xs font-medium text-[#B91C1C] inline-flex items-center gap-1">
                  Open city guide
                  <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3. Popular Local Dishes Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1F1510]">
            Iconic Dishes of Vidarbha
          </h2>
          <p className="mt-1 text-sm text-[#5C4B42]">
            Click any signature dish to find places serving it across the region.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularDishesShowcase.map((dish) => (
            <button
              key={dish.name}
              type="button"
              onClick={() => onSearchSubmit(dish.name.split(' ')[0])}
              className="group text-left bg-white border border-[#E7E0D8] rounded-xl overflow-hidden hover:-translate-y-0.5 transition-transform"
            >
              <div className="aspect-[4/3] overflow-hidden bg-[#F3ECE4]">
                <SafeImage
                  src={dish.image}
                  alt={dish.name}
                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                />
              </div>
              <div className="p-4">
                <span className="text-xs font-semibold text-[#B91C1C]">{dish.city}</span>
                <h3 className="mt-0.5 font-display text-lg font-semibold text-[#1F1510] group-hover:text-[#E85D04]">
                  {dish.name}
                </h3>
                <p className="mt-1 text-xs text-[#5C4B42] line-clamp-2 leading-relaxed">
                  {dish.note}
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* 4. Trending, Featured, Hidden Gems & Recently Added */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1F1510]">
              Curated Destinations
            </h2>
            <p className="mt-1 text-sm text-[#5C4B42]">
              Switch collections to explore trending stalls, hidden gems, and newly added places.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Curated collections"
            className="inline-flex flex-wrap p-1 bg-[#EFE7DD] rounded-lg gap-1"
          >
            {(
              [
                { id: 'trending', label: 'Trending' },
                { id: 'featured', label: 'Featured' },
                { id: 'hidden', label: 'Hidden Gems' },
                { id: 'recent', label: 'Recently Added' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={activeTab === tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-white text-[#1F1510] shadow-xs'
                    : 'text-[#5C4B42] hover:text-[#1F1510]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {tabListings.map((item) => (
            <ListingCard key={item.id} listing={item} onSelect={onSelectListing} />
          ))}
        </div>
      </section>

      {/* 5. All 10 Food Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#1F1510]">
            Browse by Food Category
          </h2>
          <p className="mt-1 text-sm text-[#5C4B42]">
            Filter across street snacks, cafés, budget meals, and authentic regional kitchens.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
          {FOOD_CATEGORIES.map((cat) => (
            <button
              key={cat.name}
              type="button"
              onClick={() => onSelectCategory(cat.name)}
              className="text-left bg-white border border-[#E7E0D8] hover:border-[#E85D04] rounded-xl p-4 transition-colors"
            >
              <span className="text-[11px] font-semibold text-[#E85D04]">{cat.accent}</span>
              <h3 className="mt-1 font-display text-base font-bold text-[#1F1510]">
                {cat.name}
              </h3>
              <p className="mt-1 text-xs text-[#6B5A50] leading-relaxed">{cat.subtitle}</p>
            </button>
          ))}
        </div>
      </section>

      {/* 6. Customer Reviews & Local Food Stories Split */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7">
            <div className="flex items-end justify-between gap-4 mb-5">
              <div>
                <h2 className="font-display text-2xl font-bold text-[#1F1510]">
                  Recent Diner Reviews
                </h2>
                <p className="mt-1 text-sm text-[#5C4B42]">
                  Community tasting notes from across Vidarbha.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {recentReviews.slice(0, 4).map((rev) => (
                <div
                  key={rev.id}
                  className="bg-white border border-[#E7E0D8] rounded-xl p-5 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-semibold text-[#B91C1C] inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3" aria-hidden="true" />
                        {rev.listingCity}
                      </span>
                      <span className="inline-flex items-center gap-1 font-semibold text-[#1F1510] tabular-nums">
                        <Star className="w-3.5 h-3.5 text-[#E85D04] fill-[#E85D04]" />
                        {rev.rating}.0
                      </span>
                    </div>
                    <p className="mt-2 font-display text-base font-semibold text-[#1F1510] line-clamp-1">
                      {rev.listingName}
                    </p>
                    <p className="mt-1.5 text-sm text-[#5C4B42] line-clamp-3 leading-relaxed">
                      “{rev.comment}”
                    </p>
                  </div>
                  <div className="text-xs font-medium text-[#6B5A50]">— {rev.authorName}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="flex items-end justify-between gap-4 mb-5">
              <div>
                <h2 className="font-display text-2xl font-bold text-[#1F1510]">
                  Local Food Stories
                </h2>
                <p className="mt-1 text-sm text-[#5C4B42]">
                  Dishes, spice histories & street markets.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onOpenStories()}
                className="text-xs font-semibold text-[#E85D04] hover:underline whitespace-nowrap"
              >
                Read all stories
              </button>
            </div>

            <div className="space-y-3.5">
              {stories.slice(0, 3).map((story) => (
                <button
                  key={story.id}
                  type="button"
                  onClick={() => onOpenStories(story)}
                  className="w-full text-left bg-white border border-[#E7E0D8] hover:border-[#E85D04] rounded-xl p-4 flex items-center gap-4 transition-colors"
                >
                  <div className="w-20 h-16 rounded-lg overflow-hidden shrink-0 bg-[#F3ECE4]">
                    <SafeImage
                      src={story.imageUrl}
                      alt={story.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs text-[#6B5A50]">
                      <span className="font-semibold text-[#B91C1C]">{story.city}</span>
                      <span className="mx-1.5" aria-hidden="true">
                        ·
                      </span>
                      <span>{story.readTime}</span>
                    </div>
                    <h3 className="mt-0.5 font-display text-base font-semibold text-[#1F1510] line-clamp-2 leading-snug">
                      {story.title}
                    </h3>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
