import { ArrowRight, MapPin } from 'lucide-react';
import type { FoodListing } from '../types/index.ts';
import { VIDARBHA_CITIES } from '../data/vidarbhaMeta.ts';
import { SafeImage } from './SafeImage.tsx';

interface CitiesViewProps {
  listings: FoodListing[];
  onSelectCity: (cityName: string) => void;
}

export function CitiesView({ listings, onSelectCity }: CitiesViewProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-[#B91C1C]">
          Regional Culinary Directory
        </p>
        <h1 className="mt-1 font-display text-3xl sm:text-4xl font-bold text-[#1F1510]">
          All 11 Vidarbha Food Cities
        </h1>
        <p className="mt-2 text-sm sm:text-base text-[#5C4B42] max-w-2xl">
          Every district across Vidarbha brings its own spice craft—from Nagpur’s Saoji copper
          handis and Amravati’s Gola Bhat to Gadchiroli’s forest millet kitchens.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {VIDARBHA_CITIES.map((city) => {
          const cityCount = listings.filter((l) => l.city === city.name).length;
          return (
            <article
              key={city.name}
              className="bg-white border border-[#E7E0D8] rounded-xl overflow-hidden flex flex-col justify-between hover:-translate-y-0.5 transition-transform"
            >
              <div>
                <div className="aspect-[16/9] bg-[#F3ECE4] overflow-hidden">
                  <SafeImage
                    src={city.heroImage}
                    alt={`${city.name} culinary culture`}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-5">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-display text-2xl font-bold text-[#1F1510]">
                      {city.name}
                    </h2>
                    <span className="text-xs font-mono tabular-nums text-[#6B5A50]">
                      {cityCount} {cityCount === 1 ? 'listing' : 'listings'}
                    </span>
                  </div>

                  <p className="mt-0.5 text-xs font-semibold text-[#E85D04]">{city.tagline}</p>

                  <p className="mt-2.5 text-sm text-[#5C4B42] leading-relaxed">
                    {city.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-[#F0EAE2] space-y-1 text-xs text-[#6B5A50]">
                    <div>
                      <strong className="text-[#1F1510]">Signature dishes:</strong> {city.knownFor}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#B91C1C] shrink-0" aria-hidden="true" />
                      <span>{city.famousMarket}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="px-5 pb-5">
                <button
                  type="button"
                  onClick={() => onSelectCity(city.name)}
                  className="w-full py-2.5 px-4 rounded-lg bg-[#1F1510] hover:bg-[#E85D04] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors"
                >
                  Explore {city.name} Food Spots
                  <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
