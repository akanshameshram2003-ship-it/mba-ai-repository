import { Bookmark, MapPin, Star } from 'lucide-react';
import type { FoodListing } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { SafeImage } from './SafeImage.tsx';

interface ListingCardProps {
  listing: FoodListing;
  onSelect: (listing: FoodListing) => void;
}

export function ListingCard({ listing, onSelect }: ListingCardProps) {
  const { favoriteIds, toggleFavorite } = useAuth();
  const isSaved = favoriteIds.includes(listing.id);

  return (
    <article className="group bg-white border border-[#E7E0D8] rounded-xl overflow-hidden transition-transform duration-200 hover:-translate-y-0.5 flex flex-col">
      <div className="relative aspect-[4/3] overflow-hidden bg-[#F3ECE4]">
        <button
          type="button"
          onClick={() => onSelect(listing)}
          className="block w-full h-full text-left focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-[#E85D04]"
          aria-label={`View details for ${listing.name}`}
        >
          <SafeImage
            src={listing.imageUrl}
            alt={`${listing.name} in ${listing.city}`}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            void toggleFavorite(listing.id);
          }}
          aria-label={isSaved ? `Remove ${listing.name} from saved` : `Save ${listing.name}`}
          className={`absolute top-3 right-3 w-10 h-10 rounded-lg flex items-center justify-center border transition-colors ${
            isSaved
              ? 'bg-[#E85D04] border-[#E85D04] text-white'
              : 'bg-white/95 border-[#E7E0D8] text-[#1F1510] hover:bg-[#FAF8F5]'
          }`}
        >
          <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
        </button>
      </div>

      <div className="p-5 flex-1 flex flex-col justify-between gap-4">
        <div>
          {/* Unboxed typographic metadata line (Zero-Pill Discipline) */}
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#6B5A50] mb-1.5">
            <span className="font-semibold text-[#B91C1C]">{listing.city}</span>
            <span aria-hidden="true">·</span>
            <span>{listing.category}</span>
            <span aria-hidden="true">·</span>
            <span
              className={
                listing.dietary === 'Veg'
                  ? 'text-[#15803D] font-medium'
                  : 'text-[#6B5A50] font-medium'
              }
            >
              {listing.dietary}
            </span>
          </div>

          <button
            type="button"
            onClick={() => onSelect(listing)}
            className="text-left block w-full group-hover:text-[#E85D04] transition-colors"
          >
            <h3 className="font-display text-lg font-semibold text-[#1F1510] leading-snug line-clamp-1">
              {listing.name}
            </h3>
          </button>

          <p className="mt-1.5 text-sm text-[#5C4B42] line-clamp-2 leading-relaxed">
            {listing.speciality}
          </p>
        </div>

        <div className="pt-3 border-t border-[#F0EAE2] flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 min-w-0">
            <span className="inline-flex items-center gap-1 font-semibold text-[#1F1510] tabular-nums shrink-0">
              <Star className="w-3.5 h-3.5 text-[#E85D04] fill-[#E85D04]" aria-hidden="true" />
              {listing.rating.toFixed(1)}
              <span className="font-normal text-[#6B5A50]">({listing.reviewCount})</span>
            </span>
            <span aria-hidden="true" className="text-[#D6C9BC]">
              |
            </span>
            <span className="font-mono tabular-nums text-[#5C4B42] truncate">
              ₹{listing.priceMin}–₹{listing.priceMax}
            </span>
          </div>

          <span className="inline-flex items-center gap-1 text-[#6B5A50] whitespace-nowrap shrink-0">
            <MapPin className="w-3 h-3 shrink-0" aria-hidden="true" />
            {listing.isVerified ? 'Verified Business' : 'Sample Demo'}
          </span>
        </div>
      </div>
    </article>
  );
}
