import React, { useCallback, useEffect, useState } from 'react';
import {
  Check,
  Edit3,
  ImagePlus,
  Plus,
  Shield,
  Trash2,
  X,
} from 'lucide-react';
import type { AdminStats, FoodListing, ReviewItem, SubmissionItem } from '../types/index.ts';
import { FOOD_CATEGORIES, VIDARBHA_CITIES } from '../data/vidarbhaMeta.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { SafeImage } from './SafeImage.tsx';

interface AdminDashboardViewProps {
  onDataChanged: () => void;
}

type AdminTab = 'listings' | 'submissions' | 'reviews';

export function AdminDashboardView({ onDataChanged }: AdminDashboardViewProps) {
  const { user, token, authFetch, claimAdmin, openAuthModal } = useAuth();

  const [authStatus, setAuthStatus] = useState<{
    adminClaimed: boolean;
    passcodeConfigured: boolean;
  } | null>(null);

  const [claimName, setClaimName] = useState('');
  const [claimEmail, setClaimEmail] = useState('');
  const [claimPassword, setClaimPassword] = useState('');
  const [claimPasscode, setClaimPasscode] = useState('');
  const [claimError, setClaimError] = useState<string | null>(null);
  const [claiming, setClaiming] = useState(false);

  const [activeTab, setActiveTab] = useState<AdminTab>('listings');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [listings, setListings] = useState<FoodListing[]>([]);
  const [submissions, setSubmissions] = useState<SubmissionItem[]>([]);
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [loading, setLoading] = useState(false);

  // Add/Edit Listing Form State
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [fName, setFName] = useState('');
  const [fCity, setFCity] = useState('Nagpur');
  const [fCategory, setFCategory] = useState('Street Food');
  const [fSpeciality, setFSpeciality] = useState('');
  const [fDescription, setFDescription] = useState('');
  const [fAddress, setFAddress] = useState('');
  const [fPhone, setFPhone] = useState('+91 00000 00000');
  const [fHours, setFHours] = useState('9:00 AM – 10:30 PM');
  const [fPriceMin, setFPriceMin] = useState('60');
  const [fPriceMax, setFPriceMax] = useState('250');
  const [fDietary, setFDietary] = useState<'Veg' | 'Non-Veg' | 'Veg & Non-Veg'>('Veg');
  const [fImage, setFImage] = useState('/src/assets/images/dish_tarri_poha_1795245658651.jpg');
  const [fVerified, setFVerified] = useState(true);
  const [fTrending, setFTrending] = useState(false);
  const [fHiddenGem, setFHiddenGem] = useState(false);
  const [fFeatured, setFFeatured] = useState(false);
  const [savingListing, setSavingListing] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [adminFeedback, setAdminFeedback] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/auth/status')
      .then((r) => r.json())
      .then((data) => setAuthStatus(data))
      .catch(() => setAuthStatus({ adminClaimed: false, passcodeConfigured: false }));
  }, [user]);

  const loadOverview = useCallback(async () => {
    if (!token || user?.role !== 'admin') return;
    setLoading(true);
    try {
      const res = await authFetch('/api/admin/overview');
      if (res.ok) {
        const data = await res.json();
        setStats(data.stats);
        setListings(data.listings || []);
        setSubmissions(data.submissions || []);
        setReviews(data.reviews || []);
      }
    } finally {
      setLoading(false);
    }
  }, [token, user, authFetch]);

  useEffect(() => {
    void loadOverview();
  }, [loadOverview]);

  const handleClaimAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setClaimError(null);
    setClaiming(true);
    try {
      await claimAdmin({
        name: claimName,
        email: claimEmail,
        password: claimPassword,
        passcode: claimPasscode || undefined,
      });
    } catch (err) {
      setClaimError(err instanceof Error ? err.message : 'Unable to claim admin access.');
    } finally {
      setClaiming(false);
    }
  };

  const openNewForm = () => {
    setEditingId(null);
    setFName('');
    setFCity('Nagpur');
    setFCategory('Street Food');
    setFSpeciality('');
    setFDescription('');
    setFAddress('');
    setFPhone('+91 00000 00000');
    setFHours('9:00 AM – 10:30 PM');
    setFPriceMin('60');
    setFPriceMax('250');
    setFDietary('Veg');
    setFImage('/src/assets/images/dish_tarri_poha_1795245658651.jpg');
    setFVerified(true);
    setFTrending(false);
    setFHiddenGem(false);
    setFFeatured(false);
    setFormOpen(true);
  };

  const openEditForm = (item: FoodListing) => {
    setEditingId(item.id);
    setFName(item.name);
    setFCity(item.city);
    setFCategory(item.category);
    setFSpeciality(item.speciality);
    setFDescription(item.description);
    setFAddress(item.address);
    setFPhone(item.phone);
    setFHours(item.openingHours);
    setFPriceMin(String(item.priceMin));
    setFPriceMax(String(item.priceMax));
    setFDietary(item.dietary);
    setFImage(item.imageUrl);
    setFVerified(item.isVerified);
    setFTrending(item.isTrending);
    setFHiddenGem(item.isHiddenGem);
    setFFeatured(item.isFeatured);
    setFormOpen(true);
  };

  const handleAdminUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('File read error'));
        reader.readAsDataURL(file);
      });
      const res = await authFetch('/api/upload', {
        method: 'POST',
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (res.ok && data.imageUrl) {
        setFImage(data.imageUrl);
      }
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSaveListing = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingListing(true);
    setAdminFeedback(null);
    try {
      const payload = {
        name: fName,
        city: fCity,
        category: fCategory,
        speciality: fSpeciality,
        description: fDescription || fSpeciality,
        address: fAddress,
        phone: fPhone,
        openingHours: fHours,
        priceMin: Number(fPriceMin),
        priceMax: Number(fPriceMax),
        dietary: fDietary,
        imageUrl: fImage,
        isVerified: fVerified,
        isTrending: fTrending,
        isHiddenGem: fHiddenGem,
        isFeatured: fFeatured,
      };
      const url = editingId ? `/api/admin/listings/${editingId}` : '/api/admin/listings';
      const method = editingId ? 'PATCH' : 'POST';
      const res = await authFetch(url, { method, body: JSON.stringify(payload) });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to save listing');
      }
      setFormOpen(false);
      setAdminFeedback(editingId ? 'Listing updated.' : 'New food listing published.');
      await loadOverview();
      onDataChanged();
    } catch (err) {
      setAdminFeedback(err instanceof Error ? err.message : 'Save error.');
    } finally {
      setSavingListing(false);
    }
  };

  const handleToggleListingFlag = async (
    item: FoodListing,
    field: 'isVerified' | 'isTrending' | 'isHiddenGem' | 'isFeatured'
  ) => {
    await authFetch(`/api/admin/listings/${item.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ [field]: !item[field] }),
    });
    await loadOverview();
    onDataChanged();
  };

  const handleDeleteListing = async (id: number) => {
    await authFetch(`/api/admin/listings/${id}`, { method: 'DELETE' });
    setAdminFeedback('Listing deleted.');
    await loadOverview();
    onDataChanged();
  };

  const handleModerateSubmission = async (id: number, status: 'approved' | 'rejected') => {
    await authFetch(`/api/admin/submissions/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        status,
        adminNote:
          status === 'approved'
            ? 'Verified and published to TarriTrail.'
            : 'Insufficient location details provided.',
      }),
    });
    setAdminFeedback(
      status === 'approved'
        ? 'Recommendation approved and published as Verified Business.'
        : 'Recommendation marked as rejected.'
    );
    await loadOverview();
    onDataChanged();
  };

  const handleDeleteReview = async (id: number) => {
    await authFetch(`/api/admin/reviews/${id}`, { method: 'DELETE' });
    setAdminFeedback('Review deleted and rating recalculated.');
    await loadOverview();
    onDataChanged();
  };

  // Gate: Non-admin or unauthenticated
  if (!user || user.role !== 'admin') {
    const canClaim = authStatus ? !authStatus.adminClaimed || authStatus.passcodeConfigured : true;

    return (
      <div className="max-w-xl mx-auto px-4 py-12 sm:py-16 space-y-6">
        <div className="bg-white border border-[#E7E0D8] rounded-xl p-6 sm:p-8 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#1F1510] text-white flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-[#1F1510]">
                TarriTrail Admin Console
              </h1>
              <p className="text-xs text-[#6B5A50]">
                Protected management panel for listings, approvals, reviews & statistics.
              </p>
            </div>
          </div>

          {canClaim ? (
            <form onSubmit={handleClaimAdmin} className="space-y-4 pt-2 border-t border-[#F0EAE2]">
              <p className="text-xs text-[#5C4B42] leading-relaxed">
                {authStatus?.passcodeConfigured
                  ? 'Enter your administrator passcode and credentials to unlock the dashboard.'
                  : 'First-run Admin Setup: Create your administrator account below to claim control of the dashboard. Once claimed, this setup locks automatically.'}
              </p>

              <div>
                <label htmlFor="adm-name" className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Admin Name
                </label>
                <input
                  id="adm-name"
                  type="text"
                  required
                  value={claimName}
                  onChange={(e) => setClaimName(e.target.value)}
                  placeholder="e.g. Vidarbha Editor"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
                />
              </div>

              <div>
                <label htmlFor="adm-email" className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Admin Email
                </label>
                <input
                  id="adm-email"
                  type="email"
                  required
                  value={claimEmail}
                  onChange={(e) => setClaimEmail(e.target.value)}
                  placeholder="admin@tarritrail.in"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
                />
              </div>

              <div>
                <label htmlFor="adm-pass" className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Choose Admin Password
                </label>
                <input
                  id="adm-pass"
                  type="password"
                  required
                  minLength={6}
                  value={claimPassword}
                  onChange={(e) => setClaimPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
                />
              </div>

              {authStatus?.passcodeConfigured && (
                <div>
                  <label
                    htmlFor="adm-code"
                    className="block text-xs font-semibold text-[#1F1510] mb-1"
                  >
                    Admin Passcode
                  </label>
                  <input
                    id="adm-code"
                    type="password"
                    required
                    value={claimPasscode}
                    onChange={(e) => setClaimPasscode(e.target.value)}
                    placeholder="Configured ADMIN_PASSCODE"
                    className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
                  />
                </div>
              )}

              {claimError && (
                <p className="text-xs font-medium text-[#B91C1C] bg-[#FEF2F2] border border-[#FECACA] px-3 py-2 rounded-lg">
                  {claimError}
                </p>
              )}

              <button
                type="submit"
                disabled={claiming}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#1F1510] hover:bg-[#E85D04] rounded-lg transition-colors"
              >
                {claiming ? 'Configuring Admin...' : 'Claim & Open Admin Dashboard'}
              </button>
            </form>
          ) : (
            <div className="space-y-4 pt-2 border-t border-[#F0EAE2]">
              <p className="text-sm text-[#5C4B42]">
                {user
                  ? `Signed in as ${user.email} (Standard User). Sign in with your Administrator account to manage listings.`
                  : 'Administrator access has already been claimed. Sign in with your administrator email and password.'}
              </p>
              <button
                type="button"
                onClick={openAuthModal}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg transition-colors"
              >
                Sign In as Administrator
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#B91C1C]">
            Admin Console · {user.email}
          </p>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#1F1510]">
            Vidarbha Directory Operations
          </h1>
        </div>

        <button
          type="button"
          onClick={openNewForm}
          className="px-4 py-2.5 text-xs font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg inline-flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          Add Food Listing
        </button>
      </div>

      {adminFeedback && (
        <div className="bg-[#F0FDF4] border border-[#BBF7D0] text-[#166534] px-4 py-2.5 rounded-lg text-xs font-medium flex items-center justify-between">
          <span>{adminFeedback}</span>
          <button type="button" onClick={() => setAdminFeedback(null)} aria-label="Dismiss notice">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Website Statistics Grid */}
      {stats && (
        <section aria-label="Platform statistics" className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
          {[
            { label: 'Total Listings', value: stats.totalListings },
            { label: 'Verified Businesses', value: stats.verifiedListings },
            { label: 'Sample Demos', value: stats.demoListings },
            { label: 'Pending Approvals', value: stats.pendingSubmissions },
            { label: 'Customer Reviews', value: stats.totalReviews },
            { label: 'Cities Covered', value: `${stats.citiesCovered}/11` },
          ].map((m) => (
            <div key={m.label} className="bg-white border border-[#E7E0D8] rounded-xl p-4">
              <div className="font-mono text-2xl font-bold text-[#1F1510] tabular-nums">
                {m.value}
              </div>
              <div className="mt-1 text-xs text-[#6B5A50]">{m.label}</div>
            </div>
          ))}
        </section>
      )}

      {/* Section Tabs */}
      <div className="inline-flex p-1 bg-[#EFE7DD] rounded-lg gap-1">
        {(
          [
            { id: 'listings', label: `Food Listings (${listings.length})` },
            {
              id: 'submissions',
              label: `Pending Recommendations (${
                submissions.filter((s) => s.status === 'pending').length
              })`,
            },
            { id: 'reviews', label: `Reviews (${reviews.length})` },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-[#1F1510] shadow-xs'
                : 'text-[#5C4B42] hover:text-[#1F1510]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Add / Edit Listing Modal */}
      {formOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/55 overflow-y-auto p-4 flex justify-center items-start"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleSaveListing}
            className="bg-white border border-[#E7E0D8] rounded-xl w-full max-w-2xl p-6 sm:p-8 my-6 space-y-5"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-bold text-[#1F1510]">
                {editingId ? 'Edit Food Listing' : 'Add New Food Listing'}
              </h2>
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                className="p-2 rounded-lg text-[#6B5A50] hover:bg-[#F3ECE4]"
                aria-label="Close listing editor"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">Name *</label>
                <input
                  type="text"
                  required
                  value={fName}
                  onChange={(e) => setFName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">City *</label>
                <select
                  value={fCity}
                  onChange={(e) => setFCity(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                >
                  {VIDARBHA_CITIES.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Category *
                </label>
                <select
                  value={fCategory}
                  onChange={(e) => setFCategory(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                >
                  {FOOD_CATEGORIES.map((cat) => (
                    <option key={cat.name} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Speciality *
                </label>
                <input
                  type="text"
                  required
                  value={fSpeciality}
                  onChange={(e) => setFSpeciality(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Complete Address *
                </label>
                <input
                  type="text"
                  required
                  value={fAddress}
                  onChange={(e) => setFAddress(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">Hours</label>
                <input
                  type="text"
                  value={fHours}
                  onChange={(e) => setFHours(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">Phone</label>
                <input
                  type="text"
                  value={fPhone}
                  onChange={(e) => setFPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Min Price (₹)
                </label>
                <input
                  type="number"
                  value={fPriceMin}
                  onChange={(e) => setFPriceMin(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Max Price (₹)
                </label>
                <input
                  type="number"
                  value={fPriceMax}
                  onChange={(e) => setFPriceMax(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">Dietary</label>
                <select
                  value={fDietary}
                  onChange={(e) => setFDietary(e.target.value as 'Veg' | 'Non-Veg' | 'Veg & Non-Veg')}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                >
                  <option value="Veg">Veg</option>
                  <option value="Non-Veg">Non-Veg</option>
                  <option value="Veg & Non-Veg">Veg & Non-Veg</option>
                </select>
              </div>

              <div className="flex items-center gap-3 pt-5">
                <label className="inline-flex items-center gap-2 text-xs font-semibold text-[#1F1510]">
                  <input
                    type="checkbox"
                    checked={fVerified}
                    onChange={(e) => setFVerified(e.target.checked)}
                    className="accent-[#E85D04]"
                  />
                  Verified Business
                </label>
              </div>

              <div className="sm:col-span-2 flex flex-wrap gap-5 pt-1">
                <label className="inline-flex items-center gap-2 text-xs font-medium text-[#5C4B42]">
                  <input
                    type="checkbox"
                    checked={fTrending}
                    onChange={(e) => setFTrending(e.target.checked)}
                    className="accent-[#E85D04]"
                  />
                  Trending
                </label>
                <label className="inline-flex items-center gap-2 text-xs font-medium text-[#5C4B42]">
                  <input
                    type="checkbox"
                    checked={fFeatured}
                    onChange={(e) => setFFeatured(e.target.checked)}
                    className="accent-[#E85D04]"
                  />
                  Featured
                </label>
                <label className="inline-flex items-center gap-2 text-xs font-medium text-[#5C4B42]">
                  <input
                    type="checkbox"
                    checked={fHiddenGem}
                    onChange={(e) => setFHiddenGem(e.target.checked)}
                    className="accent-[#E85D04]"
                  />
                  Hidden Gem
                </label>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#1F1510] mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={fDescription}
                  onChange={(e) => setFDescription(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg"
                />
              </div>

              <div className="sm:col-span-2 flex items-center gap-4">
                <div className="w-24 aspect-[4/3] rounded-lg overflow-hidden border border-[#E7E0D8]">
                  <SafeImage src={fImage} alt="Listing preview" className="w-full h-full object-cover" />
                </div>
                <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border border-[#D8CEC3] rounded-lg cursor-pointer hover:bg-[#FAF8F5]">
                  <ImagePlus className="w-4 h-4 text-[#E85D04]" />
                  {uploadingImage ? 'Uploading...' : 'Upload Food Photo'}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={handleAdminUpload}
                    className="sr-only"
                  />
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                className="px-4 py-2 text-xs font-semibold border border-[#D8CEC3] rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingListing || uploadingImage}
                className="px-5 py-2 text-xs font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg"
              >
                {savingListing ? 'Saving...' : editingId ? 'Update Listing' : 'Publish Listing'}
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <p className="text-sm text-[#6B5A50]">Loading dashboard data...</p>
      ) : activeTab === 'listings' ? (
        <div className="bg-white border border-[#E7E0D8] rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#E7E0D8] bg-[#FAF8F5] text-[#6B5A50]">
                <th className="py-3 px-4 font-semibold">Food Place</th>
                <th className="py-3 px-4 font-semibold">City · Category</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Highlights</th>
                <th className="py-3 px-4 font-semibold text-right">Rating</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F0EAE2]">
              {listings.map((item) => (
                <tr key={item.id} className="hover:bg-[#FAF8F5]/70">
                  <td className="py-3 px-4 font-semibold text-[#1F1510]">
                    <div>{item.name}</div>
                    <div className="font-normal text-[#6B5A50] truncate max-w-[260px]">
                      {item.speciality}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-[#5C4B42] whitespace-nowrap">
                    {item.city} · {item.category}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => void handleToggleListingFlag(item, 'isVerified')}
                      className={`font-semibold underline underline-offset-4 ${
                        item.isVerified ? 'text-[#15803D]' : 'text-[#B45309]'
                      }`}
                    >
                      {item.isVerified ? 'Verified Business' : 'Sample Demo'}
                    </button>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap space-x-2">
                    <button
                      type="button"
                      onClick={() => void handleToggleListingFlag(item, 'isTrending')}
                      className={item.isTrending ? 'font-semibold text-[#E85D04]' : 'text-[#9C8B80]'}
                    >
                      Trending
                    </button>
                    <span>·</span>
                    <button
                      type="button"
                      onClick={() => void handleToggleListingFlag(item, 'isHiddenGem')}
                      className={item.isHiddenGem ? 'font-semibold text-[#B91C1C]' : 'text-[#9C8B80]'}
                    >
                      Hidden Gem
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-[#1F1510]">
                    {item.rating.toFixed(1)} ({item.reviewCount})
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                    <button
                      type="button"
                      onClick={() => openEditForm(item)}
                      className="p-1.5 rounded hover:bg-[#EFE7DD] text-[#1F1510]"
                      aria-label={`Edit ${item.name}`}
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDeleteListing(item.id)}
                      className="p-1.5 rounded hover:bg-[#FEE2E2] text-[#B91C1C]"
                      aria-label={`Delete ${item.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : activeTab === 'submissions' ? (
        <div className="space-y-4">
          {submissions.length === 0 ? (
            <div className="bg-white border border-[#E7E0D8] rounded-xl p-8 text-center text-sm text-[#6B5A50]">
              No community recommendations submitted yet.
            </div>
          ) : (
            submissions.map((sub) => (
              <div
                key={sub.id}
                className="bg-white border border-[#E7E0D8] rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  <div className="w-24 aspect-[4/3] rounded-lg overflow-hidden bg-[#F3ECE4] shrink-0">
                    <SafeImage
                      src={sub.imageUrl}
                      alt={sub.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs text-[#6B5A50]">
                      <span className="font-semibold text-[#B91C1C]">{sub.city}</span>
                      <span className="mx-1.5">·</span>
                      <span>{sub.category}</span>
                      <span className="mx-1.5">·</span>
                      <span className="capitalize font-semibold">{sub.status}</span>
                    </div>
                    <h3 className="font-display text-lg font-bold text-[#1F1510]">{sub.name}</h3>
                    <p className="text-xs text-[#5C4B42]">{sub.speciality}</p>
                    <p className="text-xs text-[#6B5A50]">
                      Address: {sub.address} · Submitted by {sub.submitterName} ({sub.submitterEmail})
                    </p>
                  </div>
                </div>

                {sub.status === 'pending' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void handleModerateSubmission(sub.id, 'approved')}
                      className="px-3.5 py-2 text-xs font-semibold text-white bg-[#15803D] hover:bg-[#166534] rounded-lg inline-flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Approve & Publish
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleModerateSubmission(sub.id, 'rejected')}
                      className="px-3.5 py-2 text-xs font-semibold text-[#B91C1C] bg-white border border-[#FECACA] hover:bg-[#FEF2F2] rounded-lg"
                    >
                      Reject
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      ) : (
        <div className="bg-white border border-[#E7E0D8] rounded-xl divide-y divide-[#F0EAE2]">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="text-xs text-[#6B5A50]">
                  <strong className="text-[#1F1510]">{rev.listingName}</strong> ({rev.listingCity})
                  <span className="mx-1.5">·</span>
                  <span>By {rev.authorName}</span>
                  <span className="mx-1.5">·</span>
                  <span className="font-mono">{rev.rating}/5</span>
                </div>
                <p className="mt-1 text-sm text-[#5C4B42]">{rev.comment}</p>
              </div>
              <button
                type="button"
                onClick={() => void handleDeleteReview(rev.id)}
                className="px-3 py-1.5 text-xs font-semibold text-[#B91C1C] border border-[#FECACA] rounded-lg hover:bg-[#FEF2F2] shrink-0 self-start sm:self-center"
              >
                Delete Review
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
