import { useEffect, useState } from 'react';
import { Bookmark, Compass } from 'lucide-react';
import type { FoodListing, SubmissionItem } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { ListingCard } from './ListingCard.tsx';

interface SavedFavoritesViewProps {
  onSelectListing: (listing: FoodListing) => void;
  onExplore: () => void;
}

export function SavedFavoritesView({ onSelectListing, onExplore }: SavedFavoritesViewProps) {
  const { user, token, authFetch, openAuthModal } = useAuth();
  const [favorites, setFavorites] = useState<FoodListing[]>([]);
  const [submissions, setSubmissions] = useState<SubmissionItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    setLoading(true);
    Promise.all([
      authFetch('/api/favorites').then((r) => (r.ok ? r.json() : [])),
      authFetch('/api/submissions/mine').then((r) => (r.ok ? r.json() : [])),
    ])
      .then(([favData, subData]) => {
        if (!cancelled) {
          setFavorites(Array.isArray(favData) ? favData : []);
          setSubmissions(Array.isArray(subData) ? subData : []);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [token, authFetch]);

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <Bookmark className="w-10 h-10 text-[#E85D04] mx-auto" aria-hidden="true" />
        <h1 className="font-display text-3xl font-bold text-[#1F1510]">
          Sign in to view your saved Vidarbha places
        </h1>
        <p className="text-sm text-[#5C4B42]">
          Keep track of favourite breakfast stalls, Saoji kitchens, and your submitted hidden gems.
        </p>
        <button
          type="button"
          onClick={openAuthModal}
          className="px-5 py-2.5 text-sm font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg transition-colors"
        >
          Sign In or Create Account
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      <div>
        <h1 className="font-display text-3xl font-bold text-[#1F1510]">
          Saved Places & Submissions
        </h1>
        <p className="mt-1 text-sm text-[#5C4B42]">
          Signed in as {user.name} ({user.email})
        </p>
      </div>

      <section className="space-y-4">
        <h2 className="font-display text-2xl font-bold text-[#1F1510]">
          Saved Food Spots ({favorites.length})
        </h2>

        {loading ? (
          <p className="text-sm text-[#6B5A50]">Loading saved places...</p>
        ) : favorites.length === 0 ? (
          <div className="bg-white border border-[#E7E0D8] rounded-xl p-8 text-center space-y-3">
            <p className="text-sm text-[#5C4B42]">
              You have not bookmarked any Vidarbha food places yet.
            </p>
            <button
              type="button"
              onClick={onExplore}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#E85D04] rounded-lg"
            >
              <Compass className="w-4 h-4" aria-hidden="true" />
              Discover Food Places
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((item) => (
              <ListingCard key={item.id} listing={item} onSelect={onSelectListing} />
            ))}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <h2 className="font-display text-2xl font-bold text-[#1F1510]">
          Your Submitted Recommendations ({submissions.length})
        </h2>

        {submissions.length === 0 ? (
          <p className="text-sm text-[#6B5A50]">
            No recommendations submitted yet. Visit “Submit Gem” to suggest a local spot.
          </p>
        ) : (
          <div className="bg-white border border-[#E7E0D8] rounded-xl divide-y divide-[#F0EAE2]">
            {submissions.map((sub) => (
              <div
                key={sub.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="text-xs text-[#6B5A50]">
                    <span className="font-semibold text-[#B91C1C]">{sub.city}</span>
                    <span className="mx-1.5" aria-hidden="true">
                      ·
                    </span>
                    <span>{sub.category}</span>
                  </div>
                  <h3 className="font-display text-base font-semibold text-[#1F1510]">
                    {sub.name}
                  </h3>
                  <p className="text-xs text-[#5C4B42]">{sub.speciality}</p>
                </div>

                <div className="text-right">
                  <span
                    className={`text-xs font-semibold capitalize ${
                      sub.status === 'approved'
                        ? 'text-[#15803D]'
                        : sub.status === 'rejected'
                        ? 'text-[#B91C1C]'
                        : 'text-[#B45309]'
                    }`}
                  >
                    Status: {sub.status}
                  </span>
                  {sub.adminNote && (
                    <p className="text-xs text-[#6B5A50] mt-0.5">Note: {sub.adminNote}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
