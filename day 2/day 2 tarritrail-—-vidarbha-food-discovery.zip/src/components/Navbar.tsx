import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

export type AppPage = 'home' | 'discover' | 'cities' | 'stories' | 'submit' | 'favorites' | 'admin';

interface NavbarProps {
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
}

export function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const { user, openAuthModal, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: AppPage; label: string }[] = [
    { id: 'discover', label: 'Discover' },
    { id: 'cities', label: 'Cities' },
    { id: 'stories', label: 'Stories' },
    { id: 'submit', label: 'Submit Gem' },
    { id: 'admin', label: 'Admin' },
  ];

  const handleNav = (page: AppPage) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-sm border-b border-[#E7E0D8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark + Emblem */}
        <button
          type="button"
          onClick={() => handleNav('home')}
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E85D04] rounded-md"
        >
          <svg
            width="28"
            height="28"
            viewBox="0 0 32 32"
            fill="none"
            aria-hidden="true"
            className="shrink-0"
          >
            <rect width="32" height="32" rx="8" fill="#1F1510" />
            <path
              d="M8 18.5C8 22.6421 11.5817 26 16 26C20.4183 26 24 22.6421 24 18.5H8Z"
              fill="#E85D04"
            />
            <path
              d="M16 6C14.2 8.4 13.5 10.6 15.2 12.6C16.6 14.2 16 15.5 16 15.5C16 15.5 19.2 14 19.2 10.8C19.2 8.3 17.4 6.9 16 6Z"
              fill="#FAF8F5"
            />
          </svg>
          <span className="font-display text-xl font-bold tracking-tight text-[#1F1510]">
            TarriTrail
          </span>
        </button>

        {/* Zone 2: 5 clean single-line text links */}
        <nav
          aria-label="Primary"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-[#5C4B42]"
        >
          {navItems.map((item) => {
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E85D04] ${
                  active
                    ? 'text-[#1F1510] border-[#E85D04] font-semibold'
                    : 'border-transparent hover:text-[#1F1510] hover:border-[#D6C9BC]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {user ? (
            <div className="hidden md:flex items-center gap-4">
              <button
                type="button"
                onClick={() => handleNav('favorites')}
                className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors ${
                  currentPage === 'favorites'
                    ? 'text-[#E85D04] font-semibold'
                    : 'text-[#5C4B42] hover:text-[#1F1510]'
                }`}
              >
                Saved Places
              </button>
              <button
                type="button"
                onClick={logout}
                className="px-4 py-2 text-xs font-semibold text-[#1F1510] bg-white border border-[#D8CEC3] rounded-lg hover:bg-[#F3ECE4] transition-colors whitespace-nowrap shrink-0"
                title={`Signed in as ${user.email}`}
              >
                Sign Out ({user.name.split(' ')[0]})
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={openAuthModal}
              className="hidden md:inline-flex px-4 py-2 text-xs font-semibold text-white bg-[#E85D04] rounded-lg hover:bg-[#D04E00] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E85D04]"
            >
              Sign In
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            className="md:hidden p-2.5 rounded-lg border border-[#E7E0D8] text-[#1F1510] hover:bg-[#F3ECE4]"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E7E0D8] bg-[#FAF8F5] px-4 py-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNav(item.id)}
              className={`block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${
                currentPage === item.id
                  ? 'bg-[#EFE7DD] text-[#1F1510] font-semibold'
                  : 'text-[#5C4B42] hover:bg-[#F3ECE4]'
              }`}
            >
              {item.label}
            </button>
          ))}
          {user ? (
            <>
              <button
                type="button"
                onClick={() => handleNav('favorites')}
                className="block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-[#5C4B42] hover:bg-[#F3ECE4]"
              >
                Saved Places
              </button>
              <button
                type="button"
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold text-[#B91C1C] hover:bg-[#F3ECE4]"
              >
                Sign Out ({user.name})
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                openAuthModal();
              }}
              className="w-full py-2.5 px-4 rounded-lg text-sm font-semibold text-white bg-[#E85D04]"
            >
              Sign In / Create Account
            </button>
          )}
        </div>
      )}
    </header>
  );
}
