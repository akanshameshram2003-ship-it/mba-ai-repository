import { useState } from 'react';
import { ArrowLeft, BookOpen, ChefHat } from 'lucide-react';
import type { FoodStory } from '../types/index.ts';
import { SafeImage } from './SafeImage.tsx';

interface StoriesViewProps {
  stories: FoodStory[];
  initialStory: FoodStory | null;
  onExploreCity: (city: string) => void;
}

export function StoriesView({ stories, initialStory, onExploreCity }: StoriesViewProps) {
  const [activeStory, setActiveStory] = useState<FoodStory | null>(initialStory);

  if (activeStory) {
    return (
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
        <button
          type="button"
          onClick={() => setActiveStory(null)}
          className="inline-flex items-center gap-2 text-xs font-semibold text-[#5C4B42] hover:text-[#1F1510]"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          Back to Local Food Stories
        </button>

        <header className="space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#6B5A50]">
            <span className="font-semibold text-[#B91C1C]">{activeStory.city}</span>
            <span aria-hidden="true">·</span>
            <span>{activeStory.topic}</span>
            <span aria-hidden="true">·</span>
            <span>{activeStory.readTime}</span>
            <span aria-hidden="true">·</span>
            <span>{activeStory.publishedAt}</span>
          </div>
          <h1
            className="font-display text-3xl sm:text-4xl font-bold text-[#1F1510] leading-tight"
            style={{ textWrap: 'balance' }}
          >
            {activeStory.title}
          </h1>
          <p className="text-base sm:text-lg text-[#5C4B42] leading-relaxed">
            {activeStory.subtitle}
          </p>
          <p className="text-xs font-medium text-[#6B5A50]">By {activeStory.author}</p>
        </header>

        <div className="aspect-[16/9] rounded-xl overflow-hidden border border-[#E7E0D8] bg-[#F3ECE4]">
          <SafeImage
            src={activeStory.imageUrl}
            alt={activeStory.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="space-y-5 text-base text-[#362821] leading-relaxed max-w-prose">
          {activeStory.content.map((paragraph, i) => (
            <p key={i}>{paragraph}</p>
          ))}
        </div>

        {activeStory.recipeHighlights && (
          <section className="bg-white border border-[#E7E0D8] rounded-xl p-6 sm:p-8 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <ChefHat className="w-5 h-5 text-[#E85D04]" aria-hidden="true" />
                <h2 className="font-display text-xl font-bold text-[#1F1510]">
                  Traditional Recipe Notes: {activeStory.recipeHighlights.dishName}
                </h2>
              </div>
              <span className="text-xs font-mono text-[#6B5A50]">
                Prep: {activeStory.recipeHighlights.prepTime}
              </span>
            </div>

            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#6B5A50] mb-2">
                Key Regional Ingredients
              </h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-[#1F1510]">
                {activeStory.recipeHighlights.keyIngredients.map((ing) => (
                  <li key={ing} className="flex items-start gap-2">
                    <span className="text-[#E85D04] font-bold" aria-hidden="true">
                      ·
                    </span>
                    <span>{ing}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-3 border-t border-[#F0EAE2]">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#6B5A50] mb-1.5">
                Method Summary
              </h3>
              <p className="text-sm text-[#5C4B42] leading-relaxed">
                {activeStory.recipeHighlights.methodSummary}
              </p>
            </div>
          </section>
        )}

        <div className="pt-4 border-t border-[#E7E0D8] flex flex-wrap items-center justify-between gap-4">
          <span className="text-sm text-[#5C4B42]">
            Ready to taste this heritage in person?
          </span>
          <button
            type="button"
            onClick={() => onExploreCity(activeStory.city)}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] rounded-lg transition-colors"
          >
            Explore {activeStory.city} Food Spots
          </button>
        </div>
      </article>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-[#B91C1C]">
          Vidarbha Culinary Journal
        </p>
        <h1 className="mt-1 font-display text-3xl sm:text-4xl font-bold text-[#1F1510]">
          Local Food Stories & Heirloom Recipes
        </h1>
        <p className="mt-2 text-sm sm:text-base text-[#5C4B42] max-w-2xl">
          Deep dives into the spice histories, street food markets, and traditional home kitchens
          shaping Vidarbha’s table.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stories.map((story) => (
          <article
            key={story.id}
            className="bg-white border border-[#E7E0D8] rounded-xl overflow-hidden flex flex-col justify-between hover:-translate-y-0.5 transition-transform"
          >
            <div>
              <button
                type="button"
                onClick={() => setActiveStory(story)}
                className="block w-full aspect-[16/10] bg-[#F3ECE4] overflow-hidden text-left"
              >
                <SafeImage
                  src={story.imageUrl}
                  alt={story.title}
                  className="w-full h-full object-cover"
                />
              </button>

              <div className="p-5">
                <div className="flex items-center gap-2 text-xs text-[#6B5A50]">
                  <span className="font-semibold text-[#B91C1C]">{story.city}</span>
                  <span aria-hidden="true">·</span>
                  <span>{story.topic}</span>
                  <span aria-hidden="true">·</span>
                  <span>{story.readTime}</span>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveStory(story)}
                  className="mt-1.5 text-left block w-full hover:text-[#E85D04] transition-colors"
                >
                  <h2 className="font-display text-xl font-bold text-[#1F1510] leading-snug">
                    {story.title}
                  </h2>
                </button>

                <p className="mt-2 text-sm text-[#5C4B42] line-clamp-3 leading-relaxed">
                  {story.excerpt}
                </p>
              </div>
            </div>

            <div className="px-5 pb-5 pt-3 border-t border-[#F0EAE2] flex items-center justify-between">
              <span className="text-xs text-[#6B5A50]">{story.author}</span>
              <button
                type="button"
                onClick={() => setActiveStory(story)}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#E85D04] hover:underline"
              >
                <BookOpen className="w-3.5 h-3.5" aria-hidden="true" />
                Read Story
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
