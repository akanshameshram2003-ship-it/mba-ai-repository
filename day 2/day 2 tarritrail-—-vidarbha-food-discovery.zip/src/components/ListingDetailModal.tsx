import React, { useEffect, useState } from 'react';
import {
  Bookmark,
  Clock,
  ExternalLink,
  ImagePlus,
  MapPin,
  Navigation,
  Phone,
  ShieldCheck,
  Star,
  X,
} from 'lucide-react';
import type { FoodListing, ReviewItem } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { SafeImage } from './SafeImage.tsx';

interface ListingDetailModalProps {
  listing: FoodListing | null;
  onClose: () => void;
  onListingUpdated: (updated: FoodListing) => void;
}

export function ListingDetailModal({
  listing,
  onClose,
  onListingUpdated,
}: ListingDetailModalProps) {
  const { user, favoriteIds, toggleFavorite, authFetch, openAuthModal } = useAuth();
  const [detailListing, setDetailListing] = useState<FoodListing | null>(listing);
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(false);

  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [uploadedImageUrl, setUploadedImageUrl] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewSuccess, setReviewSuccess] = useState<string | null>(null);

  useEffect(() => {
    setDetailListing(listing);
    setReviewError(null);
    setReviewSuccess(null);
    setComment('');
    setUploadedImageUrl('');
    if (!listing) return;

    let cancelled = false;
    setLoadingReviews(true);
    fetch(`/api/listings/${listing.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (!cancelled && data.listing) {
          setDetailListing(data.listing);
          setReviews(Array.isArray(data.reviews) ? data.reviews : []);
        }
      })
      .catch(() => {
        if (!cancelled) setReviews([]);
      })
      .finally(() => {
        if (!cancelled) setLoadingReviews(false);
      });

    return () => {
      cancelled = true;
    };
  }, [listing]);

  if (!listing || !detailListing) return null;

  const isSaved = favoriteIds.includes(detailListing.id);
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
    `${detailListing.lat},${detailListing.lng}`
  )}`;
  const mapsSearchUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${detailListing.city}, Vidarbha, Maharashtra`
  )}`;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!user) {
      openAuthModal();
      return;
    }

    setReviewError(null);
    setUploadingPhoto(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('Failed to read image file.'));
        reader.readAsDataURL(file);
      });

      const res = await authFetch('/api/upload', {
        method: 'POST',
        body: JSON.stringify({ dataUrl, filename: file.name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed.');
      setUploadedImageUrl(data.imageUrl);
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Unable to upload photo.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }

    setReviewError(null);
    setReviewSuccess(null);
    setSubmittingReview(true);

    try {
      const res = await authFetch(`/api/listings/${detailListing.id}/reviews`, {
        method: 'POST',
        body: JSON.stringify({
          rating,
          comment,
          imageUrl: uploadedImageUrl || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not submit review.');

      setReviews((prev) => [data.review, ...prev]);
      setDetailListing(data.listing);
      onListingUpdated(data.listing);
      setComment('');
      setUploadedImageUrl('');
      setRating(5);
      setReviewSuccess('Thank you! Your review has been published.');
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Failed to post review.');
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 overflow-y-auto p-3 sm:p-6 flex justify-center items-start"
      role="dialog"
      aria-modal="true"
      aria-labelledby="listing-detail-title"
    >
      <div className="bg-white border border-[#E7E0D8] rounded-xl w-full max-w-4xl overflow-hidden my-4">
        <div className="relative h-64 sm:h-80 bg-[#F3ECE4]">
          <SafeImage
            src={detailListing.imageUrl}
            alt={detailListing.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent" />

          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 rounded-lg bg-white/95 text-[#1F1510] flex items-center justify-center hover:bg-white transition-colors"
            aria-label="Close place details"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-5 left-5 right-5 flex flex-col sm:flex-row sm:items-end justify-between gap-4 text-white">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-white/90 mb-1.5">
                <span className="font-semibold text-[#FDBA74]">{detailListing.city}</span>
                <span aria-hidden="true">·</span>
                <span>{detailListing.category}</span>
                <span aria-hidden="true">·</span>
                <span>{detailListing.dietary}</span>
              </div>
              <h2 id="listing-detail-title" className="font-display text-2xl sm:text-3xl font-bold leading-tight">
                {detailListing.name}
              </h2>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="bg-white/15 backdrop-blur-sm border border-white/25 rounded-lg px-3.5 py-2 text-center">
                <div className="flex items-center gap-1 font-bold text-base tabular-nums">
                  <Star className="w-4 h-4 text-[#FBBF24] fill-[#FBBF24]" aria-hidden="true" />
                  {detailListing.rating.toFixed(1)}
                </div>
                <div className="text-[11px] text-white/85 tabular-nums">
                  {detailListing.reviewCount} reviews
                </div>
              </div>

              <button
                type="button"
                onClick={() => void toggleFavorite(detailListing.id)}
                className={`px-4 py-2.5 rounded-lg text-xs font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap ${
                  isSaved
                    ? 'bg-[#E85D04] text-white'
                    : 'bg-white text-[#1F1510] hover:bg-[#FAF8F5]'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                {isSaved ? 'Saved' : 'Save Place'}
              </button>
            </div>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-8">
          {/* Verified vs Sample Demo Distinction */}
          <div
            className={`px-4 py-3 rounded-lg border text-xs flex flex-wrap items-center justify-between gap-2 ${
              detailListing.isVerified
                ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#166534]'
                : 'bg-[#FFFBEB] border-[#FDE68A] text-[#92400E]'
            }`}
          >
            <div className="flex items-center gap-2 font-medium">
              <ShieldCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
              {detailListing.isVerified ? (
                <span>
                  <strong>Verified Business:</strong> Approved and verified by TarriTrail editorial administration.
                </span>
              ) : (
                <span>
                  <strong>Sample Demo Listing:</strong> Illustrative Vidarbha showcase listing with placeholder address and contact details.
                </span>
              )}
            </div>
            <span className="font-mono tabular-nums">
              Approx. ₹{detailListing.priceMin}–₹{detailListing.priceMax} for two
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h3 className="font-display text-lg font-semibold text-[#1F1510]">
                  About & Speciality
                </h3>
                <p className="mt-2 text-sm text-[#5C4B42] leading-relaxed">
                  {detailListing.description}
                </p>
                <p className="mt-2 text-sm font-medium text-[#1F1510]">
                  Signature focus: {detailListing.speciality}
                </p>
              </div>

              {detailListing.popularDishes.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#6B5A50] mb-2.5">
                    Must-Try Dishes
                  </h4>
                  <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-[#1F1510]">
                    {detailListing.popularDishes.map((dish, idx) => (
                      <span key={dish} className="inline-flex items-center gap-2 font-medium">
                        {idx > 0 && (
                          <span aria-hidden="true" className="text-[#D6C9BC]">
                            /
                          </span>
                        )}
                        {dish}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Reviews Section */}
              <div className="pt-6 border-t border-[#E7E0D8]">
                <h3 className="font-display text-xl font-semibold text-[#1F1510] mb-4">
                  Customer Reviews ({detailListing.reviewCount})
                </h3>

                {/* Write a review */}
                <form
                  onSubmit={handleReviewSubmit}
                  className="bg-[#FAF8F5] border border-[#E7E0D8] rounded-xl p-4 sm:p-5 mb-6 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="text-sm font-semibold text-[#1F1510]">
                      Share your dining experience
                    </span>
                    <div className="flex items-center gap-1" role="group" aria-label="Star rating">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="p-1 focus-visible:outline-2 focus-visible:outline-[#E85D04] rounded"
                          aria-label={`Rate ${star} out of 5 stars`}
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= rating
                                ? 'text-[#E85D04] fill-[#E85D04]'
                                : 'text-[#D6C9BC]'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea
                    rows={3}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder={
                      user
                        ? 'What dish did you try? Share taste, spice level, or timing tips...'
                        : 'Sign in to post a review or upload a food photograph...'
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
                  />

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <label className="inline-flex items-center gap-2 text-xs font-medium text-[#5C4B42] hover:text-[#1F1510] cursor-pointer py-1.5 px-3 bg-white border border-[#D8CEC3] rounded-lg">
                      <ImagePlus className="w-4 h-4 text-[#E85D04]" aria-hidden="true" />
                      <span>{uploadingPhoto ? 'Uploading photo...' : 'Add Food Photo'}</span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={handlePhotoUpload}
                        className="sr-only"
                      />
                    </label>

                    <button
                      type="submit"
                      disabled={submittingReview || uploadingPhoto}
                      className="px-4 py-2 text-xs font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] disabled:opacity-60 rounded-lg transition-colors"
                    >
                      {user
                        ? submittingReview
                          ? 'Posting...'
                          : 'Post Review'
                        : 'Sign In to Review'}
                    </button>
                  </div>

                  {uploadedImageUrl && (
                    <div className="flex items-center gap-3 pt-1">
                      <SafeImage
                        src={uploadedImageUrl}
                        alt="Uploaded review dish"
                        className="w-16 h-12 rounded-md object-cover border border-[#E7E0D8]"
                      />
                      <span className="text-xs text-[#15803D] font-medium">
                        Photo attached to review
                      </span>
                    </div>
                  )}

                  {reviewError && (
                    <p className="text-xs text-[#B91C1C] font-medium">{reviewError}</p>
                  )}
                  {reviewSuccess && (
                    <p className="text-xs text-[#15803D] font-medium">{reviewSuccess}</p>
                  )}
                </form>

                {loadingReviews ? (
                  <p className="text-sm text-[#6B5A50]">Loading reviews...</p>
                ) : reviews.length === 0 ? (
                  <p className="text-sm text-[#6B5A50]">
                    No reviews yet. Be the first food lover to share your notes.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {reviews.map((rev) => (
                      <div
                        key={rev.id}
                        className="border-b border-[#F0EAE2] pb-4 last:border-b-0"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-[#1F1510]">
                            {rev.authorName}
                          </span>
                          <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#1F1510] tabular-nums">
                            <Star className="w-3.5 h-3.5 text-[#E85D04] fill-[#E85D04]" />
                            {rev.rating}.0
                          </span>
                        </div>
                        <p className="mt-1.5 text-sm text-[#5C4B42] leading-relaxed">
                          {rev.comment}
                        </p>
                        {rev.imageUrl && (
                          <div className="mt-2.5 w-40 aspect-[4/3] rounded-lg overflow-hidden border border-[#E7E0D8]">
                            <SafeImage
                              src={rev.imageUrl}
                              alt={`Dish photo by ${rev.authorName}`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right Sidebar: Address, Hours, Contact & Map Directions */}
            <aside className="space-y-5">
              <div className="bg-[#FAF8F5] border border-[#E7E0D8] rounded-xl p-5 space-y-4">
                <h3 className="font-display text-base font-semibold text-[#1F1510]">
                  Location & Hours
                </h3>

                <div className="space-y-3 text-sm text-[#5C4B42]">
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-[#E85D04] mt-0.5 shrink-0" aria-hidden="true" />
                    <span>{detailListing.address}</span>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-[#E85D04] mt-0.5 shrink-0" aria-hidden="true" />
                    <span className="tabular-nums">{detailListing.openingHours}</span>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <Phone className="w-4 h-4 text-[#E85D04] mt-0.5 shrink-0" aria-hidden="true" />
                    <span className="font-mono text-xs tabular-nums">{detailListing.phone}</span>
                  </div>
                </div>

                {/* Coordinate & Directions Box */}
                <div className="pt-3 border-t border-[#E7E0D8] space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#6B5A50]">
                    <span>Region Coordinates</span>
                    <span className="font-mono tabular-nums">
                      {detailListing.lat.toFixed(4)}° N, {detailListing.lng.toFixed(4)}° E
                    </span>
                  </div>

                  <a
                    href={directionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-lg bg-[#1F1510] hover:bg-[#38261D] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors"
                  >
                    <Navigation className="w-4 h-4" aria-hidden="true" />
                    Get Directions in Google Maps
                  </a>

                  <a
                    href={mapsSearchUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-4 rounded-lg bg-white border border-[#D8CEC3] hover:bg-[#F3ECE4] text-[#1F1510] text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>Explore {detailListing.city} on Maps</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  );
}
