import React, { useState } from 'react';
import { X } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

export function AuthModal() {
  const { authModalOpen, closeAuthModal, login, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (!authModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === 'login') {
        await login(email, password);
      } else {
        await register(name, email, password);
      }
      setName('');
      setEmail('');
      setPassword('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="bg-white border border-[#E7E0D8] rounded-xl w-full max-w-md p-6 sm:p-8 relative">
        <button
          type="button"
          onClick={closeAuthModal}
          className="absolute top-4 right-4 p-2 rounded-lg text-[#6B5A50] hover:bg-[#F3ECE4] hover:text-[#1F1510]"
          aria-label="Close sign in dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 id="auth-modal-title" className="font-display text-2xl font-bold text-[#1F1510]">
          {mode === 'login' ? 'Sign In to TarriTrail' : 'Join TarriTrail'}
        </h2>
        <p className="mt-1.5 text-sm text-[#6B5A50]">
          {mode === 'login'
            ? 'Save favourite Vidarbha food spots, write reviews, and submit hidden gems.'
            : 'Create your free food explorer account across all 11 Vidarbha cities.'}
        </p>

        <div className="mt-5 flex p-1 bg-[#F3ECE4] rounded-lg">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors ${
              mode === 'login'
                ? 'bg-white text-[#1F1510] shadow-xs'
                : 'text-[#6B5A50] hover:text-[#1F1510]'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors ${
              mode === 'register'
                ? 'bg-white text-[#1F1510] shadow-xs'
                : 'text-[#6B5A50] hover:text-[#1F1510]'
            }`}
          >
            Create Account
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {mode === 'register' && (
            <div>
              <label htmlFor="auth-name" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
                Full Name
              </label>
              <input
                id="auth-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Aarav Deshmukh"
                className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
              />
            </div>
          )}

          <div>
            <label htmlFor="auth-email" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Email Address
            </label>
            <input
              id="auth-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          <div>
            <label htmlFor="auth-password" className="block text-xs font-semibold text-[#1F1510] mb-1.5">
              Password
            </label>
            <input
              id="auth-password"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
              className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#D8CEC3] rounded-lg focus:outline-none focus:border-[#E85D04]"
            />
          </div>

          {error && (
            <p className="text-xs font-medium text-[#B91C1C] bg-[#FEF2F2] border border-[#FECACA] px-3 py-2 rounded-lg">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#E85D04] hover:bg-[#D04E00] disabled:opacity-60 rounded-lg transition-colors"
          >
            {submitting
              ? 'Please wait...'
              : mode === 'login'
              ? 'Sign In'
              : 'Create Free Account'}
          </button>
        </form>
      </div>
    </div>
  );
}
