import { VIDARBHA_CITIES } from '../data/vidarbhaMeta.ts';
import type { AppPage } from './Navbar.tsx';

interface FooterProps {
  onNavigate: (page: AppPage) => void;
  onSelectCity: (city: string) => void;
}

export function Footer({ onNavigate, onSelectCity }: FooterProps) {
  return (
    <footer className="bg-[#1F1510] text-[#E7E0D8] mt-16 border-t border-[#362821]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-12 gap-8">
        <div className="md:col-span-5 space-y-3">
          <div className="font-display text-2xl font-bold text-white">TarriTrail</div>
          <p className="text-sm text-[#C7B8AC] max-w-sm leading-relaxed">
            Explore Vidarbha, One Bite at a Time. Promoting authentic regional flavours from
            Nagpur’s dawn Tarri Poha stalls to Gadchiroli’s forest millet kitchens.
          </p>
          <p className="text-xs text-[#9C8B80] leading-relaxed">
            Data transparency: Seeded showcase entries are clearly marked as Sample Demo Listings
            with illustrative locations until verified by an administrator.
          </p>
        </div>

        <div className="md:col-span-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-[#FDBA74] mb-3">
            Vidarbha Cities
          </h3>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
            {VIDARBHA_CITIES.map((city) => (
              <button
                key={city.name}
                type="button"
                onClick={() => onSelectCity(city.name)}
                className="text-left text-[#D6C9BC] hover:text-white transition-colors"
              >
                {city.name}
              </button>
            ))}
          </div>
        </div>

        <div className="md:col-span-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-[#FDBA74] mb-3">
            Platform
          </h3>
          <div className="space-y-2 text-xs">
            <button
              type="button"
              onClick={() => onNavigate('discover')}
              className="block text-[#D6C9BC] hover:text-white"
            >
              Food Discovery
            </button>
            <button
              type="button"
              onClick={() => onNavigate('cities')}
              className="block text-[#D6C9BC] hover:text-white"
            >
              11 District Guides
            </button>
            <button
              type="button"
              onClick={() => onNavigate('stories')}
              className="block text-[#D6C9BC] hover:text-white"
            >
              Local Food Stories
            </button>
            <button
              type="button"
              onClick={() => onNavigate('submit')}
              className="block text-[#D6C9BC] hover:text-white"
            >
              Suggest a Hidden Gem
            </button>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className="block text-[#D6C9BC] hover:text-white"
            >
              Admin Console
            </button>
          </div>
        </div>
      </div>

      <div className="border-t border-[#362821] py-5 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#9C8B80]">
        <span>© {new Date().getFullYear()} TarriTrail Vidarbha Food Discovery.</span>
        <span>Built for Vidarbha’s 11 Districts, Maharashtra.</span>
      </div>
    </footer>
  );
}
