import React, { createContext, useCallback, useContext, useState } from 'react';
import type { UserProfile } from '../types/index.ts';

interface AuthContextValue {
  token: string | null;
  user: UserProfile | null;
  favoriteIds: number[];
  authModalOpen: boolean;
  openAuthModal: () => void;
  closeAuthModal: () => void;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  claimAdmin: (params: {
    name: string;
    email: string;
    password: string;
    passcode?: string;
  }) => Promise<void>;
  logout: () => void;
  toggleFavorite: (listingId: number) => Promise<boolean>;
  authFetch: (input: string, init?: RequestInit) => Promise<Response>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Keep token strictly in React memory (never localStorage/sessionStorage)
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [favoriteIds, setFavoriteIds] = useState<number[]>([]);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const openAuthModal = useCallback(() => setAuthModalOpen(true), []);
  const closeAuthModal = useCallback(() => setAuthModalOpen(false), []);

  const authFetch = useCallback(
    async (input: string, init: RequestInit = {}) => {
      const headers = new Headers(init.headers);
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      if (!headers.has('Content-Type') && init.body && typeof init.body === 'string') {
        headers.set('Content-Type', 'application/json');
      }
      return fetch(input, { ...init, headers });
    },
    [token]
  );

  const login = useCallback(async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Unable to sign in.');
    }
    setToken(data.token);
    setUser(data.user);
    setFavoriteIds(Array.isArray(data.favoriteIds) ? data.favoriteIds : []);
    setAuthModalOpen(false);
  }, []);

  const register = useCallback(async (name: string, email: string, password: string) => {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Unable to create account.');
    }
    setToken(data.token);
    setUser(data.user);
    setFavoriteIds(Array.isArray(data.favoriteIds) ? data.favoriteIds : []);
    setAuthModalOpen(false);
  }, []);

  const claimAdmin = useCallback(
    async (params: { name: string; email: string; password: string; passcode?: string }) => {
      const res = await fetch('/api/auth/admin-claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unable to claim admin access.');
      }
      setToken(data.token);
      setUser(data.user);
      setFavoriteIds(Array.isArray(data.favoriteIds) ? data.favoriteIds : []);
    },
    []
  );

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    setFavoriteIds([]);
  }, []);

  const toggleFavorite = useCallback(
    async (listingId: number) => {
      if (!token) {
        setAuthModalOpen(true);
        return false;
      }
      const res = await fetch(`/api/favorites/${listingId}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return false;
      const data = await res.json();
      setFavoriteIds(Array.isArray(data.favoriteIds) ? data.favoriteIds : []);
      return Boolean(data.saved);
    },
    [token]
  );

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        favoriteIds,
        authModalOpen,
        openAuthModal,
        closeAuthModal,
        login,
        register,
        claimAdmin,
        logout,
        toggleFavorite,
        authFetch,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
