import { db, recomputeListingRating } from './db.ts';

interface SeedListing {
  name: string;
  slug: string;
  city: string;
  category: string;
  speciality: string;
  description: string;
  address: string;
  phone: string;
  openingHours: string;
  priceMin: number;
  priceMax: number;
  budgetTier: 'Budget' | 'Moderate' | 'Premium';
  dietary: 'Veg' | 'Non-Veg' | 'Veg & Non-Veg';
  imageUrl: string;
  lat: number;
  lng: number;
  isTrending: number;
  isHiddenGem: number;
  isFeatured: number;
  popularDishes: string[];
  reviews: { author: string; rating: number; comment: string }[];
}

const IMG_TARRI = '/src/assets/images/dish_tarri_poha_1795245658651.jpg';
const IMG_SAOJI = '/src/assets/images/dish_saoji_curry_1795245657802.jpg';
const IMG_BARFI = '/src/assets/images/dish_santra_barfi_1795245658533.jpg';
const IMG_PATODI = '/src/assets/images/dish_patodi_bhakri_1795245658746.jpg';
const IMG_MARKET = '/src/assets/images/story_food_market_1795245659189.jpg';
const IMG_HERO = '/src/assets/images/hero_vidarbha_feast_1795245658502.jpg';

const SEED_LISTINGS: SeedListing[] = [
  {
    name: 'Kasturchand Morning Tarri Poha Corner',
    slug: 'kasturchand-morning-tarri-poha-nagpur',
    city: 'Nagpur',
    category: 'Breakfast Spots',
    speciality: 'Black-gram spicy Tarri Poha with crunchy sev and masala samosa',
    description:
      'Sample breakfast stall celebrating Nagpur’s iconic early-morning Tarri Poha ritual—steaming flattened rice ladled with slow-simmered roasted-spice chana tarri, diced onions, and crisp sev.',
    address: 'Sample Demo Location: Near Sitabuldi Crossing, Nagpur 440012 (Illustrative)',
    phone: '+91 00000 10101',
    openingHours: '6:00 AM – 11:30 AM',
    priceMin: 30,
    priceMax: 90,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_TARRI,
    lat: 21.1498,
    lng: 79.0806,
    isTrending: 1,
    isHiddenGem: 0,
    isFeatured: 1,
    popularDishes: ['Tarri Poha', 'Tarri Samosa', 'Aloo Bonda', 'Masala Chai'],
    reviews: [
      {
        author: 'Rohan Deshmukh',
        rating: 5,
        comment: 'Classic Nagpur morning flavour—the black-gram tarri carries deep roasted clove and chilli warmth without overpowering the light poha.'
      },
      {
        author: 'Snehal Kulkarni',
        rating: 5,
        comment: 'Sample review: Quick breakfast stop with generous sev topping and piping hot samosas.'
      }
    ]
  },
  {
    name: 'Halba Saoji Copper Handi Kitchen',
    slug: 'halba-saoji-copper-handi-nagpur',
    city: 'Nagpur',
    category: 'Non-Vegetarian Specialities',
    speciality: 'Stone-ground 24-spice Saoji Mutton & Chicken Rassa',
    description:
      'An illustrative heritage bhojanalay showcasing traditional Halba-Koshti community cooking with roasted dagad phool, black cardamom, poppy seeds, and Bhivapur red chillies.',
    address: 'Sample Demo Location: Lakadganj Spice Lane, East Nagpur 440008 (Illustrative)',
    phone: '+91 00000 10102',
    openingHours: '12:00 PM – 3:30 PM, 7:00 PM – 11:00 PM',
    priceMin: 240,
    priceMax: 520,
    budgetTier: 'Moderate',
    dietary: 'Non-Veg',
    imageUrl: IMG_SAOJI,
    lat: 21.1539,
    lng: 79.1187,
    isTrending: 1,
    isHiddenGem: 0,
    isFeatured: 1,
    popularDishes: ['Saoji Mutton Handi', 'Saoji Chicken Kala Masala', 'Patodi Rassa', 'Tandoori Roti'],
    reviews: [
      {
        author: 'Aditya Joshi',
        rating: 5,
        comment: 'Deep dark-crimson masala with unmistakable stone-flower aroma. Best paired with crisp rotis and fresh lime.'
      }
    ]
  },
  {
    name: 'Santra Nagari Mithai Atelier',
    slug: 'santra-nagari-mithai-nagpur',
    city: 'Nagpur',
    category: 'Sweets and Desserts',
    speciality: 'Fresh Nagpur Mandarin Santra Barfi & Saffron Malai Pedha',
    description:
      'Sample heritage sweet counter crafting slow-reduced khoya fudges infused with fresh Nagpur orange pulp, cardamom, and toasted pistachios.',
    address: 'Sample Demo Location: Dharampeth High Street, Nagpur 440010 (Illustrative)',
    phone: '+91 00000 10103',
    openingHours: '8:30 AM – 10:00 PM',
    priceMin: 120,
    priceMax: 480,
    budgetTier: 'Moderate',
    dietary: 'Veg',
    imageUrl: IMG_BARFI,
    lat: 21.1419,
    lng: 79.0628,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 1,
    popularDishes: ['Santra Barfi', 'Orange Kalakand', 'Pista Kesar Pedha', 'Kulfi Falooda'],
    reviews: [
      {
        author: 'Meera Patwardhan',
        rating: 5,
        comment: 'Bright citrus aroma balanced against rich milk fudge—our go-to gift box whenever visiting Nagpur.'
      }
    ]
  },
  {
    name: 'Dharampeth Roastery & Bhakri Café',
    slug: 'dharampeth-roastery-bhakri-cafe',
    city: 'Nagpur',
    category: 'Cafés',
    speciality: 'Cold brew coffee, fusion tarri toasties & baked pudachi vadi',
    description:
      'A youthful illustrative café blending Vidarbha snack nostalgia with specialty espresso, pour-overs, and crisp baked coriander rolls.',
    address: 'Sample Demo Location: Shankar Nagar Lane 4, Nagpur 440010 (Illustrative)',
    phone: '+91 00000 10104',
    openingHours: '9:30 AM – 11:30 PM',
    priceMin: 160,
    priceMax: 420,
    budgetTier: 'Moderate',
    dietary: 'Veg',
    imageUrl: IMG_HERO,
    lat: 21.1355,
    lng: 79.0598,
    isTrending: 1,
    isHiddenGem: 1,
    isFeatured: 0,
    popularDishes: ['Orange Cold Brew', 'Baked Pudachi Vadi', 'Thecha Cheese Sandwich'],
    reviews: [
      {
        author: 'Tanvi Gadkari',
        rating: 4,
        comment: 'Great Wi-Fi, calm ambience, and surprisingly addictive green chilli thecha toasties.'
      }
    ]
  },
  {
    name: 'Rajkamal Chaat & Gola Bhat Cart',
    slug: 'rajkamal-chaat-gola-bhat-amravati',
    city: 'Amravati',
    category: 'Street Food',
    speciality: 'Amravati-style Gola Bhat with spiced kadhi and tamarind ragda',
    description:
      'An illustrative evening street stall showcasing Amravati’s beloved Gola Bhat—steamed spiced gram-flour dumplings nestled over fragrant rice and tangy kadhi.',
    address: 'Sample Demo Location: Rajkamal Chowk Market, Amravati 444601 (Illustrative)',
    phone: '+91 00000 10201',
    openingHours: '4:30 PM – 10:30 PM',
    priceMin: 40,
    priceMax: 120,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_MARKET,
    lat: 20.9312,
    lng: 77.7519,
    isTrending: 1,
    isHiddenGem: 1,
    isFeatured: 1,
    popularDishes: ['Gola Bhat & Kadhi', 'Amravati Ragda Pattice', 'Kothimbir Vadi'],
    reviews: [
      {
        author: 'Pratik Mohod',
        rating: 5,
        comment: 'Warm, comforting, and super affordable for college evenings near Rajkamal Square.'
      }
    ]
  },
  {
    name: 'Camp Road Misal & Brew House',
    slug: 'camp-road-misal-brew-amravati',
    city: 'Amravati',
    category: 'Fast Food',
    speciality: 'Fiery Kat Misal Pav, Crispy Sabudana Vada & Cold Coffee',
    description:
      'Sample youth hangout serving brisk quick-bite platters, layered spicy farsan misal, and thick whipped cold coffee.',
    address: 'Sample Demo Location: Camp Area Main Road, Amravati 444602 (Illustrative)',
    phone: '+91 00000 10202',
    openingHours: '8:00 AM – 10:30 PM',
    priceMin: 60,
    priceMax: 180,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_TARRI,
    lat: 20.9374,
    lng: 77.7721,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Zanzanit Kat Misal', 'Sabudana Vada', 'Thick Cold Coffee'],
    reviews: [
      {
        author: 'Nikhil Bhende',
        rating: 4,
        comment: 'Fast counter service and balanced spice levels on the misal kat.'
      }
    ]
  },
  {
    name: 'Sevagram Gramin Jhunka Bhakri Ghar',
    slug: 'sevagram-jhunka-bhakri-wardha',
    city: 'Wardha',
    category: 'Traditional Vidarbha Food',
    speciality: 'Wood-fired Jowar Bhakri, Besan Jhunka & Kharad Thecha',
    description:
      'Illustrative family kitchen celebrating Wardha’s timeless rural plate: hand-patted jowar bhakri, slow-cooked spiced gram flour jhunka, and roasted peanut chutney.',
    address: 'Sample Demo Location: Sevagram Road, Wardha 442001 (Illustrative)',
    phone: '+91 00000 10301',
    openingHours: '11:00 AM – 3:30 PM, 6:30 PM – 9:30 PM',
    priceMin: 90,
    priceMax: 180,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_PATODI,
    lat: 20.7351,
    lng: 78.6258,
    isTrending: 1,
    isHiddenGem: 1,
    isFeatured: 1,
    popularDishes: ['Jhunka Bhakri Thali', 'Patodi Rassa', 'Shengdana Chutney', 'Taak'],
    reviews: [
      {
        author: 'Kavita Sawant',
        rating: 5,
        comment: 'Tastes just like a village courtyard lunch. The roasted garlic-chilli thecha is unforgettable.'
      }
    ]
  },
  {
    name: 'Bajaj Square Moong Dal Vada Stall',
    slug: 'bajaj-square-dal-vada-wardha',
    city: 'Wardha',
    category: 'Budget-Friendly Food',
    speciality: 'Crisp green-chilli Moong Dal Vada & Tarri Poha',
    description:
      'Sample street-side snack bar loved by morning commuters and students for fresh hot dal vadas paired with mint chutney.',
    address: 'Sample Demo Location: Bajaj Square Corner, Wardha 442001 (Illustrative)',
    phone: '+91 00000 10302',
    openingHours: '7:00 AM – 1:00 PM, 4:00 PM – 8:30 PM',
    priceMin: 25,
    priceMax: 80,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_TARRI,
    lat: 20.7462,
    lng: 78.6011,
    isTrending: 0,
    isHiddenGem: 1,
    isFeatured: 0,
    popularDishes: ['Moong Dal Vada', 'Mirchi Bhajji', 'Kanda Poha'],
    reviews: [
      {
        author: 'Saurabh Bawankule',
        rating: 4,
        comment: 'Super crisp vadas straight out of the kadhai and very easy on the pocket.'
      }
    ]
  },
  {
    name: 'Wainganga Patodi & Wada Bhat Kitchen',
    slug: 'wainganga-patodi-wada-bhat-bhandara',
    city: 'Bhandara',
    category: 'Traditional Vidarbha Food',
    speciality: 'Steamed Besan Patodi in spicy crimson rassa with fragrant Chinnor rice',
    description:
      'Illustrative regional kitchen highlighting Bhandara’s famous aromatic paddy harvest alongside spiced diamond-cut patodi and wada bhat.',
    address: 'Sample Demo Location: Gandhi Chowk Bazaar, Bhandara 441904 (Illustrative)',
    phone: '+91 00000 10401',
    openingHours: '11:30 AM – 4:00 PM, 7:00 PM – 10:00 PM',
    priceMin: 110,
    priceMax: 260,
    budgetTier: 'Budget',
    dietary: 'Veg & Non-Veg',
    imageUrl: IMG_PATODI,
    lat: 21.1745,
    lng: 79.6525,
    isTrending: 1,
    isHiddenGem: 1,
    isFeatured: 0,
    popularDishes: ['Patodi Rassa', 'Wada Bhat', 'Bhandara Fish Fry'],
    reviews: [
      {
        author: 'Deepak Hatwar',
        rating: 5,
        comment: 'Soft patodi squares soaking up fiery kala masala gravy—authentic eastern Vidarbha comfort.'
      }
    ]
  },
  {
    name: 'Lakeview Family Bhojanalay',
    slug: 'lakeview-family-bhojanalay-bhandara',
    city: 'Bhandara',
    category: 'Restaurants',
    speciality: 'Full Vidarbha Thali with Seasonal Bhaji, Dal Tadka & Solkadhi',
    description:
      'Sample seated family dining hall known for clean thali service, warm rotis, and seasonal local greens.',
    address: 'Sample Demo Location: Station Road, Bhandara 441904 (Illustrative)',
    phone: '+91 00000 10402',
    openingHours: '12:00 PM – 10:30 PM',
    priceMin: 150,
    priceMax: 350,
    budgetTier: 'Moderate',
    dietary: 'Veg',
    imageUrl: IMG_HERO,
    lat: 21.1812,
    lng: 79.6615,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Special Vidarbha Thali', 'Baingan Bharta', 'Jowar Bhakri'],
    reviews: [
      {
        author: 'Pooja Meshram',
        rating: 4,
        comment: 'Clean family seating and wholesome home-style cooking.'
      }
    ]
  },
  {
    name: 'Jaistambh Khapri Puranpoli & Kachori',
    slug: 'jaistambh-khapri-puranpoli-gondia',
    city: 'Gondia',
    category: 'Maharashtrian Food',
    speciality: 'Earthen-pot Khapri Puranpoli & Crisp Hing Dal Kachori',
    description:
      'Illustrative sweet-and-savoury corner famous for paper-thin puranpolis roasted on inverted earthen khapri pots, paired with spicy kachoris.',
    address: 'Sample Demo Location: Jaistambh Chowk, Gondia 441601 (Illustrative)',
    phone: '+91 00000 10501',
    openingHours: '8:00 AM – 9:30 PM',
    priceMin: 40,
    priceMax: 160,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_BARFI,
    lat: 21.4602,
    lng: 80.2179,
    isTrending: 0,
    isHiddenGem: 1,
    isFeatured: 1,
    popularDishes: ['Khapri Puranpoli with Ghee', 'Hing Dal Kachori', 'Katachi Amti'],
    reviews: [
      {
        author: 'Ankita Choure',
        rating: 5,
        comment: 'Warm ghee-brushed puranpoli with smoky khapri edges is pure nostalgia.'
      }
    ]
  },
  {
    name: 'Rail Toli Spice Kitchen',
    slug: 'rail-toli-spice-kitchen-gondia',
    city: 'Gondia',
    category: 'Restaurants',
    speciality: 'Homestyle Chana Masala, Rice Bhakri & Kala Masala Curry',
    description:
      'Sample railway-town diner welcoming travellers with hearty rice plates, spicy dals, and freshly roasted snacks.',
    address: 'Sample Demo Location: Rail Toli Main Market, Gondia 441614 (Illustrative)',
    phone: '+91 00000 10502',
    openingHours: '11:00 AM – 10:30 PM',
    priceMin: 120,
    priceMax: 290,
    budgetTier: 'Budget',
    dietary: 'Veg & Non-Veg',
    imageUrl: IMG_SAOJI,
    lat: 21.4665,
    lng: 80.2255,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Rice Bhakri & Chicken Curry', 'Jeera Rice Dal Fry', 'Masala Papad'],
    reviews: [
      {
        author: 'Vikram Agrawal',
        rating: 4,
        comment: 'Reliable stop near the station with generous portions.'
      }
    ]
  },
  {
    name: 'Tadoba Gate Saoji & Bhakri Pavilion',
    slug: 'tadoba-gate-saoji-chandrapur',
    city: 'Chandrapur',
    category: 'Non-Vegetarian Specialities',
    speciality: 'Post-safari fiery Chandrapuri Chicken Rassa & Jowar Bhakri',
    description:
      'Illustrative dining pavilion popular with Tadoba visitors and locals for smoky wood-roasted spice blends and slow-cooked curries.',
    address: 'Sample Demo Location: Jatpura Gate Road, Chandrapur 442402 (Illustrative)',
    phone: '+91 00000 10601',
    openingHours: '12:00 PM – 4:00 PM, 7:00 PM – 11:00 PM',
    priceMin: 220,
    priceMax: 490,
    budgetTier: 'Moderate',
    dietary: 'Veg & Non-Veg',
    imageUrl: IMG_SAOJI,
    lat: 19.9631,
    lng: 79.2932,
    isTrending: 1,
    isHiddenGem: 0,
    isFeatured: 1,
    popularDishes: ['Chandrapur Chicken Rassa', 'Mutton Sukka', 'Patodi Thali'],
    reviews: [
      {
        author: 'Siddharth Warjurkar',
        rating: 5,
        comment: 'Best post-safari feast in Chandrapur—deeply aromatic spices and piping hot bhakri.'
      }
    ]
  },
  {
    name: 'Gandhi Chowk Kanda Bhajji & Chai',
    slug: 'gandhi-chowk-bhajji-chandrapur',
    city: 'Chandrapur',
    category: 'Street Food',
    speciality: 'Crisp Kanda Bhajji, Pudachi Vadi & Ginger Cutting Chai',
    description:
      'Sample evening tea-time stall bustling with crispy gram-flour fritters and fried green chillies.',
    address: 'Sample Demo Location: Gandhi Chowk Lane, Chandrapur 442401 (Illustrative)',
    phone: '+91 00000 10602',
    openingHours: '4:00 PM – 10:00 PM',
    priceMin: 25,
    priceMax: 90,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_MARKET,
    lat: 19.9589,
    lng: 79.2981,
    isTrending: 0,
    isHiddenGem: 1,
    isFeatured: 0,
    popularDishes: ['Kanda Bhajji', 'Pudachi Vadi', 'Adrak Chai'],
    reviews: [
      {
        author: 'Neha Choudhary',
        rating: 4,
        comment: 'Monsoon or winter evening—nothing beats crisp kanda bhajji and spiced chai here.'
      }
    ]
  },
  {
    name: 'Bastar-Vidarbha Forest Millet Kitchen',
    slug: 'forest-millet-kitchen-gadchiroli',
    city: 'Gadchiroli',
    category: 'Traditional Vidarbha Food',
    speciality: 'Ragi Bhakri, Tender Bamboo Shoot Curry & Wild Mahua Laddoo',
    description:
      'Illustrative tribal culinary showcase celebrating Gadchiroli’s indigenous forest produce, millet flatbreads, and zero-waste heirloom recipes.',
    address: 'Sample Demo Location: Complex Market Road, Gadchiroli 442605 (Illustrative)',
    phone: '+91 00000 10701',
    openingHours: '11:30 AM – 8:30 PM',
    priceMin: 90,
    priceMax: 240,
    budgetTier: 'Budget',
    dietary: 'Veg & Non-Veg',
    imageUrl: IMG_PATODI,
    lat: 20.1818,
    lng: 80.0024,
    isTrending: 0,
    isHiddenGem: 1,
    isFeatured: 1,
    popularDishes: ['Nachni Ragi Bhakri', 'Bamboo Shoot Masala', 'Mahua Til Laddoo'],
    reviews: [
      {
        author: 'Dr. Rameshwar Gedam',
        rating: 5,
        comment: 'Rare opportunity to experience authentic forest-to-table Vidarbha tribal nutrition.'
      }
    ]
  },
  {
    name: 'Indira Chowk Mahua Sweet Mart',
    slug: 'indira-chowk-mahua-sweets-gadchiroli',
    city: 'Gadchiroli',
    category: 'Sweets and Desserts',
    speciality: 'Forest Honey Tilgul, Mahua Barfi & Fresh Jalebi',
    description:
      'Sample local sweet shop blending natural forest honey, sesame, and mahua blossoms into wholesome festive confections.',
    address: 'Sample Demo Location: Indira Gandhi Chowk, Gadchiroli 442605 (Illustrative)',
    phone: '+91 00000 10702',
    openingHours: '8:00 AM – 9:00 PM',
    priceMin: 40,
    priceMax: 200,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_BARFI,
    lat: 20.1795,
    lng: 79.9992,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Mahua Honey Barfi', 'Kesar Jalebi', 'Sesame Chikki'],
    reviews: [
      {
        author: 'Pallavi Atram',
        rating: 4,
        comment: 'Distinctive floral sweetness—wonderful local gift item.'
      }
    ]
  },
  {
    name: 'Datta Chowk Sev Bhaji & Mattha Dhaba',
    slug: 'datta-chowk-sev-bhaji-yavatmal',
    city: 'Yavatmal',
    category: 'Restaurants',
    speciality: 'Kala-masala Sev Bhaji, Besan Poli & Roasted Jeera Mattha',
    description:
      'Illustrative Vidarbha highway-style eatery loved for thick spiced ratlami-sev curry, soft rotis, and chilled earthen-pot buttermilk.',
    address: 'Sample Demo Location: Datta Chowk Market, Yavatmal 445001 (Illustrative)',
    phone: '+91 00000 10801',
    openingHours: '11:00 AM – 11:00 PM',
    priceMin: 110,
    priceMax: 280,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_HERO,
    lat: 20.3888,
    lng: 78.1289,
    isTrending: 1,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Kala Masala Sev Bhaji', 'Besan Poli', 'Matka Mattha'],
    reviews: [
      {
        author: 'Omkar Jadhav',
        rating: 5,
        comment: 'Thick, smoky sev bhaji followed by icy jeera mattha—pure Yavatmal comfort.'
      }
    ]
  },
  {
    name: 'Azad Maidan Morning Poha & Idli Hub',
    slug: 'azad-maidan-poha-yavatmal',
    city: 'Yavatmal',
    category: 'Breakfast Spots',
    speciality: 'Steaming Tarri Poha, Crispy Medu Vada & Filter Coffee',
    description:
      'Sample dawn-to-noon breakfast spot buzzing with morning walkers and students.',
    address: 'Sample Demo Location: Azad Maidan Road, Yavatmal 445001 (Illustrative)',
    phone: '+91 00000 10802',
    openingHours: '6:30 AM – 12:00 PM',
    priceMin: 30,
    priceMax: 90,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_TARRI,
    lat: 20.3915,
    lng: 78.1331,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Tarri Poha', 'Medu Vada Sambhar', 'Masala Chai'],
    reviews: [
      {
        author: 'Shreya Mahajan',
        rating: 4,
        comment: 'Always fresh at 7 AM, quick plates and clean counter.'
      }
    ]
  },
  {
    name: 'Tilak Road Heritage Dal Kachori House',
    slug: 'tilak-road-dal-kachori-akola',
    city: 'Akola',
    category: 'Street Food',
    speciality: 'Puffed Moong Dal Kachori, Bedai Sabzi & Sweet Imarti',
    description:
      'Illustrative morning farsan corner famous across Akola for flaky, spiced lentil kachoris served with tangy tamarind-date chutney.',
    address: 'Sample Demo Location: Tilak Road, Akola 444001 (Illustrative)',
    phone: '+91 00000 10901',
    openingHours: '7:00 AM – 1:30 PM, 4:30 PM – 8:30 PM',
    priceMin: 35,
    priceMax: 110,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_MARKET,
    lat: 20.7019,
    lng: 77.0074,
    isTrending: 1,
    isHiddenGem: 1,
    isFeatured: 1,
    popularDishes: ['Dal Kachori & Chutney', 'Aloo Bedai', 'Desi Ghee Imarti'],
    reviews: [
      {
        author: 'Harshvardhan Kela',
        rating: 5,
        comment: 'Unbeatable crunch on the kachori shell and tangy-sweet chutney balance.'
      }
    ]
  },
  {
    name: 'Gandhi Road Espresso & Farsan Bar',
    slug: 'gandhi-road-espresso-farsan-akola',
    city: 'Akola',
    category: 'Cafés',
    speciality: 'Artisanal Cold Coffee, Peri-Peri Bhakarwadi & Club Sandwiches',
    description:
      'Sample contemporary café pairing Akola’s love for crisp farsan with modern coffee beverages.',
    address: 'Sample Demo Location: Gandhi Road, Akola 444001 (Illustrative)',
    phone: '+91 00000 10902',
    openingHours: '10:00 AM – 11:00 PM',
    priceMin: 120,
    priceMax: 320,
    budgetTier: 'Moderate',
    dietary: 'Veg',
    imageUrl: IMG_HERO,
    lat: 20.6988,
    lng: 77.0112,
    isTrending: 0,
    isHiddenGem: 0,
    isFeatured: 0,
    popularDishes: ['Hazelnut Cold Coffee', 'Cheesy Garlic Toast', 'Spiced Bhakarwadi'],
    reviews: [
      {
        author: 'Rutuja Deshpande',
        rating: 4,
        comment: 'Cozy seating for group catchups in Akola.'
      }
    ]
  },
  {
    name: 'Patni Chowk Puranpoli & Shengdana Bhojanalay',
    slug: 'patni-chowk-puranpoli-washim',
    city: 'Washim',
    category: 'Maharashtrian Food',
    speciality: 'Ghee-soaked Puran Poli, Katachi Amti & Shengdana Chutney',
    description:
      'Illustrative traditional dining room celebrating Washim’s heirloom festive thalis and stone-ground chutneys.',
    address: 'Sample Demo Location: Patni Chowk, Washim 444505 (Illustrative)',
    phone: '+91 00000 11001',
    openingHours: '11:30 AM – 3:30 PM, 7:00 PM – 10:00 PM',
    priceMin: 100,
    priceMax: 220,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_PATODI,
    lat: 20.1128,
    lng: 77.1325,
    isTrending: 0,
    isHiddenGem: 1,
    isFeatured: 0,
    popularDishes: ['Puran Poli Thali', 'Katachi Amti', 'Jowar Bhakri Pithla'],
    reviews: [
      {
        author: 'Vaishali Ingole',
        rating: 5,
        comment: 'Warm hospitality and melt-in-the-mouth puran poli made fresh to order.'
      }
    ]
  },
  {
    name: 'Lonar Trail Khichdi & Malai Pedha House',
    slug: 'lonar-trail-khichdi-pedha-buldhana',
    city: 'Buldhana',
    category: 'Budget-Friendly Food',
    speciality: 'Ghee Masala Khichdi, Multigrain Bhajni Vada & Malai Pedha',
    description:
      'Illustrative highway stop for Lonar Crater explorers offering comforting spiced khichdi, crispy vadas, and fresh milk pedhas.',
    address: 'Sample Demo Location: Chikhli Road, Buldhana 443001 (Illustrative)',
    phone: '+91 00000 11101',
    openingHours: '7:30 AM – 10:00 PM',
    priceMin: 80,
    priceMax: 240,
    budgetTier: 'Budget',
    dietary: 'Veg',
    imageUrl: IMG_BARFI,
    lat: 20.5284,
    lng: 76.1869,
    isTrending: 0,
    isHiddenGem: 1,
    isFeatured: 0,
    popularDishes: ['Tadka Masala Khichdi', 'Bhajni Thalipeeth', 'Kesar Malai Pedha'],
    reviews: [
      {
        author: 'Kiran Borse',
        rating: 4,
        comment: 'Ideal stop before heading to Lonar Lake—fresh pedhas and soulful khichdi.'
      }
    ]
  }
];

const SEED_STORIES = [
  {
    slug: 'how-tarri-poha-became-nagpurs-6am-heartbeat',
    title: 'How Tarri Poha Became Nagpur’s 6 AM Heartbeat',
    subtitle: 'Tracing the spicy black-gram gravy that transformed humble flattened rice into Vidarbha’s ultimate morning ritual.',
    city: 'Nagpur',
    topic: 'Street Food History',
    readTime: '5 min read',
    author: 'Aarav Deshmukh',
    publishedAt: 'November 2026',
    imageUrl: IMG_TARRI,
    excerpt:
      'While western Maharashtra prefers gentle sweet-tangy kanda poha, Vidarbha wakes up to bold spice—a ladle of dark crimson chana tarri, crisp sev, and lime.',
    content: [
      'Before sunrise breaks across Nagpur’s Sitabuldi and Kasturchand Park corridors, steam rises from massive aluminium patilas. Students cycling to coaching classes, morning walkers, and office commuters gather shoulder to shoulder around stainless-steel counters.',
      'Unlike the mild lemon-and-sugar poha found elsewhere, Nagpur’s version demands contrast: soft turmeric-tinted flattened rice topped with a fiercely aromatic black-gram (kala chana) tarri slow-simmered with cloves, bay leaf, ginger-garlic paste, and Bhivapur chilli powder.',
      'A final scatter of fine nylon sev, raw chopped red onions, fresh coriander, and a squeeze of lime turns a ₹30 plate into a complete sensory symphony of crunch, heat, and brightness.'
    ],
    recipeHighlights: {
      dishName: 'Classic Nagpur Kala-Chana Tarri',
      prepTime: '35 mins',
      keyIngredients: [
        'Soaked black chickpeas (kala chana)',
        'Bhivapur red chilli powder & goda masala',
        'Stone flower (dagad phool), cloves, cinnamon',
        'Finely chopped onions, nylon sev & lime'
      ],
      methodSummary:
        'Sauté crushed ginger-garlic and whole spices until fragrant, fold in soaked kala chana with fiery red chilli paste, and simmer into a thin glossy gravy ladled piping hot over steamed poha.'
    }
  },
  {
    slug: 'inside-the-saoji-spice-pot',
    title: 'Inside the Saoji Spice Pot: 24 Botanicals & Fierce Heritage',
    subtitle: 'Why Nagpur and Chandrapur’s Halba-Koshti weaver kitchens guard one of India’s most complex spice blends.',
    city: 'Nagpur',
    topic: 'Culinary Heritage',
    readTime: '6 min read',
    author: 'Dr. Madhuri Kulkarni',
    publishedAt: 'November 2026',
    imageUrl: IMG_SAOJI,
    excerpt:
      'Saoji cuisine is never about blind heat—it is an architecture of dry-roasted coconut, stone flower, black cardamom, and poppy seeds slow-cooked in copper handis.',
    content: [
      'Historically rooted in the Halba-Koshti weaving communities who migrated and settled across Nagpur and eastern Vidarbha, Saoji cooking evolved to sustain long hours at handlooms with nutrient-dense, warming spice infusions.',
      'The secret lies in patience: over twenty whole spices—including star anise, black stone flower (dagad phool), nagkesar, khus-khus (poppy seeds), dry coconut, and coriander seeds—are toasted individually on iron tawas before being ground into a dark, fragrant kala masala.',
      'Whether enveloping tender mutton in Nagpur or crisp besan patodi in Bhandara, authentic Saoji rassa leaves a lingering warmth on the palate long after the meal ends.'
    ],
    recipeHighlights: {
      dishName: 'Traditional Vidarbha Kala Masala Base',
      prepTime: '45 mins',
      keyIngredients: [
        'Dry grated coconut & white poppy seeds',
        'Dagad phool (stone flower) & black cardamom',
        'Bhivapur dried red chillies & coriander seeds',
        'Cloves, mace (javitri) & cinnamon'
      ],
      methodSummary:
        'Dry-roast coconut until deep golden brown, separately toast whole spices on low flame, cool completely, and stone-grind into a rich aromatic paste.'
    }
  },
  {
    slug: 'bhivapur-chillies-and-rural-jhunka-bhakri',
    title: 'Bhivapur Chillies & The Soul of Rural Jhunka Bhakri',
    subtitle: 'From Wardha courtyards to Bhandara kitchens, how Vidarbha’s prized red chillies anchor everyday vegetarian feasts.',
    city: 'Wardha',
    topic: 'Traditional Recipes',
    readTime: '4 min read',
    author: 'Pranjal Sawant',
    publishedAt: 'October 2026',
    imageUrl: IMG_PATODI,
    excerpt:
      'Every agrarian household across Wardha, Bhandara, and Yavatmal celebrates the trio of hand-patted jowar bhakri, besan patodi rassa, and fiery garlic thecha.',
    content: [
      'Travel south-east from Nagpur toward Bhivapur in late winter and fields glow crimson with drying chillies—prized for their rich natural colour and balanced pungency.',
      'In Wardha and Bhandara home kitchens, those spices elevate humble pantry staples. Besan (chickpea flour) is steamed into firm diamond-shaped patodi cakes and simmered in spicy onion-garlic rassa, served alongside earthy jowar bhakri patted by hand.',
      'Accompanied by kharad—coarse crushed green chillies, roasted peanuts, and garlic—it remains one of Vidarbha’s purest expressions of farm-to-plate comfort.'
    ],
    recipeHighlights: {
      dishName: 'Patodi Rassa (Steamed Besan Diamonds in Curry)',
      prepTime: '40 mins',
      keyIngredients: [
        'Chickpea flour (besan) tempered with ajwain & turmeric',
        'Roasted onion-coconut masala paste',
        'Fresh coriander & Bhivapur red chilli',
        'Served with hand-patted Jowar Bhakri'
      ],
      methodSummary:
        'Cook tempered besan batter until thick, spread flat on a greased thali, slice into diamonds, and slip gently into simmering spiced rassa just before serving.'
    }
  },
  {
    slug: 'from-orange-orchards-to-santra-barfi',
    title: 'From Orange Orchards to Brass Platters: The Story of Santra Barfi',
    subtitle: 'How Nagpur’s winter mandarin harvest inspired a bright, citrus-perfumed mithai beloved across Maharashtra.',
    city: 'Nagpur',
    topic: 'Sweets & Culture',
    readTime: '4 min read',
    author: 'Sanket Joshi',
    publishedAt: 'October 2026',
    imageUrl: IMG_BARFI,
    excerpt:
      'Crafted without artificial essences, true Santra Barfi captures the delicate zest and juicy pulp of GI-tagged Nagpur oranges folded into slow-cooked khoya.',
    content: [
      'Every winter, Nagpur’s wholesale orange markets brim with fragrant mandarins. Sweetmakers across the region learned decades ago how to lock that fleeting winter brightness into velvety milk fudge.',
      'Authentic Santra Barfi requires careful temperature control: sweet orange pulp is reduced gently before meeting slow-simmered khoya so the milk never curdles, yielding a vibrant sunset-orange square studded with pistachios.',
      'Today it travels out of Vidarbha on trains and flights as the region’s signature edible souvenir.'
    ]
  },
  {
    slug: 'evening-street-markets-of-west-vidarbha',
    title: 'Evening Food Lanes of Amravati, Akola & Chandrapur',
    subtitle: 'A twilight trail through Gola Bhat carts, crisp Dal Kachori stalls, and buzzing college hangouts.',
    city: 'Amravati',
    topic: 'Food Markets',
    readTime: '5 min read',
    author: 'Nandini Mohod',
    publishedAt: 'October 2026',
    imageUrl: IMG_MARKET,
    excerpt:
      'As afternoon heat mellows across West Vidarbha, Rajkamal Square and Tilak Road transform into glowing open-air dining rooms.',
    content: [
      'By 5:30 PM, brass Edison bulbs flicker alive along Amravati’s Rajkamal Square and Akola’s Tilak Road. Vendors set up towering trays of puffed moong dal kachoris, sizzling tawa ragda, and steaming bowls of Amravati’s treasured Gola Bhat.',
      'Farther south in Chandrapur, travellers returning from Tadoba wildlife safaris converge around Jatpura Gate and Gandhi Chowk for crisp kanda bhajji, ginger tea, and smoky spice-forward dinners.',
      'Together, these evening markets reveal Vidarbha’s warm social fabric—affordable, unhurried, and fiercely proud of local flavour.'
    ]
  }
];

export function seedDatabase(): void {
  const existingListings = db.prepare(`SELECT COUNT(*) AS cnt FROM listings`).get() as { cnt: number };
  if (Number(existingListings.cnt) === 0) {
    const insertListing = db.prepare(`
      INSERT INTO listings (
        name, slug, city, category, speciality, description, address, phone,
        opening_hours, price_min, price_max, budget_tier, dietary, rating, review_count,
        image_url, lat, lng, is_verified, is_trending, is_hidden_gem, is_featured, popular_dishes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertReview = db.prepare(`
      INSERT INTO reviews (listing_id, user_id, author_name, rating, comment)
      VALUES (?, NULL, ?, ?, ?)
    `);

    for (const item of SEED_LISTINGS) {
      const res = insertListing.run(
        item.name,
        item.slug,
        item.city,
        item.category,
        item.speciality,
        item.description,
        item.address,
        item.phone,
        item.openingHours,
        item.priceMin,
        item.priceMax,
        item.budgetTier,
        item.dietary,
        4.5,
        item.reviews.length,
        item.imageUrl,
        item.lat,
        item.lng,
        0, // Explicitly marked Sample Demo Listing until verified by Admin
        item.isTrending,
        item.isHiddenGem,
        item.isFeatured,
        JSON.stringify(item.popularDishes)
      );

      const listingId = Number(res.lastInsertRowid);
      for (const rev of item.reviews) {
        insertReview.run(listingId, rev.author, rev.rating, rev.comment);
      }
      recomputeListingRating(listingId);
    }
  }

  const existingStories = db.prepare(`SELECT COUNT(*) AS cnt FROM stories`).get() as { cnt: number };
  if (Number(existingStories.cnt) === 0) {
    const insertStory = db.prepare(`
      INSERT INTO stories (
        slug, title, subtitle, city, topic, read_time, author, published_at,
        image_url, excerpt, content_json, recipe_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const st of SEED_STORIES) {
      insertStory.run(
        st.slug,
        st.title,
        st.subtitle,
        st.city,
        st.topic,
        st.readTime,
        st.author,
        st.publishedAt,
        st.imageUrl,
        st.excerpt,
        JSON.stringify(st.content),
        st.recipeHighlights ? JSON.stringify(st.recipeHighlights) : null
      );
    }
  }
}
