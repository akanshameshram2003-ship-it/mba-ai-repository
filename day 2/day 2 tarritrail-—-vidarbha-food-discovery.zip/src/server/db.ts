import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'tarritrail.db');
export const db = new DatabaseSync(dbPath);

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    city TEXT NOT NULL,
    category TEXT NOT NULL,
    speciality TEXT NOT NULL,
    description TEXT NOT NULL,
    address TEXT NOT NULL,
    phone TEXT NOT NULL,
    opening_hours TEXT NOT NULL,
    price_min INTEGER NOT NULL DEFAULT 50,
    price_max INTEGER NOT NULL DEFAULT 250,
    budget_tier TEXT NOT NULL DEFAULT 'Budget' CHECK (budget_tier IN ('Budget', 'Moderate', 'Premium')),
    dietary TEXT NOT NULL DEFAULT 'Veg' CHECK (dietary IN ('Veg', 'Non-Veg', 'Veg & Non-Veg')),
    rating REAL NOT NULL DEFAULT 4.4,
    review_count INTEGER NOT NULL DEFAULT 0,
    image_url TEXT NOT NULL,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    is_verified INTEGER NOT NULL DEFAULT 0,
    is_trending INTEGER NOT NULL DEFAULT 0,
    is_hidden_gem INTEGER NOT NULL DEFAULT 0,
    is_featured INTEGER NOT NULL DEFAULT 0,
    popular_dishes TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    author_name TEXT NOT NULL,
    rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT NOT NULL,
    image_url TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS favorites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(user_id, listing_id)
  );

  CREATE TABLE IF NOT EXISTS submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    submitter_name TEXT NOT NULL,
    submitter_email TEXT NOT NULL,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    category TEXT NOT NULL,
    speciality TEXT NOT NULL,
    description TEXT NOT NULL,
    address TEXT NOT NULL,
    phone TEXT NOT NULL,
    opening_hours TEXT NOT NULL,
    price_min INTEGER NOT NULL DEFAULT 50,
    price_max INTEGER NOT NULL DEFAULT 250,
    dietary TEXT NOT NULL DEFAULT 'Veg',
    is_hidden_gem INTEGER NOT NULL DEFAULT 0,
    image_url TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    admin_note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS stories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    subtitle TEXT NOT NULL,
    city TEXT NOT NULL,
    topic TEXT NOT NULL,
    read_time TEXT NOT NULL,
    author TEXT NOT NULL,
    published_at TEXT NOT NULL,
    image_url TEXT NOT NULL,
    excerpt TEXT NOT NULL,
    content_json TEXT NOT NULL,
    recipe_json TEXT
  );
`);

export function recomputeListingRating(listingId: number): void {
  const row = db
    .prepare(
      `SELECT COUNT(*) AS cnt, AVG(rating) AS avg_rating FROM reviews WHERE listing_id = ?`
    )
    .get(listingId) as { cnt: number; avg_rating: number | null } | undefined;

  const count = Number(row?.cnt ?? 0);
  const avg = row?.avg_rating ? Math.round(Number(row.avg_rating) * 10) / 10 : 4.2;

  db.prepare(`UPDATE listings SET rating = ?, review_count = ? WHERE id = ?`).run(
    avg,
    count,
    listingId
  );
}
