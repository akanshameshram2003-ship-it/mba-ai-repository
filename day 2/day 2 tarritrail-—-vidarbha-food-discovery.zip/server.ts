import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { db, recomputeListingRating } from './src/server/db.ts';
import {
  extractAuthUser,
  hasClaimedAdmin,
  hashPassword,
  requireAdmin,
  requireAuth,
  signToken,
  verifyPassword,
  type AuthRequest,
} from './src/server/auth.ts';
import { seedDatabase } from './src/server/seed.ts';
import { VIDARBHA_CITIES } from './src/data/vidarbhaMeta.ts';

seedDatabase();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const uploadsDir = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

app.use(express.json({ limit: '6mb' }));
app.use('/uploads', express.static(uploadsDir));

function safeImageUrl(raw: unknown, fallback = '/src/assets/images/dish_tarri_poha_1795245658651.jpg'): string {
  if (typeof raw !== 'string') return fallback;
  const trimmed = raw.trim();
  if (!trimmed) return fallback;
  if (trimmed.startsWith('/src/assets/') || trimmed.startsWith('/uploads/')) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
  } catch {
    // fall through
  }
  return fallback;
}

function slugify(input: string): string {
  const base = input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  const suffix = crypto.randomBytes(3).toString('hex');
  return `${base || 'spot'}-${suffix}`;
}

function mapListingRow(row: Record<string, unknown>) {
  let popularDishes: string[] = [];
  try {
    popularDishes = JSON.parse(String(row.popular_dishes || '[]'));
  } catch {
    popularDishes = [];
  }
  return {
    id: Number(row.id),
    name: String(row.name),
    slug: String(row.slug),
    city: String(row.city),
    category: String(row.category),
    speciality: String(row.speciality),
    description: String(row.description),
    address: String(row.address),
    phone: String(row.phone),
    openingHours: String(row.opening_hours),
    priceMin: Number(row.price_min),
    priceMax: Number(row.price_max),
    budgetTier: String(row.budget_tier),
    dietary: String(row.dietary),
    rating: Number(row.rating),
    reviewCount: Number(row.review_count),
    imageUrl: String(row.image_url),
    lat: Number(row.lat),
    lng: Number(row.lng),
    isVerified: Boolean(row.is_verified),
    isTrending: Boolean(row.is_trending),
    isHiddenGem: Boolean(row.is_hidden_gem),
    isFeatured: Boolean(row.is_featured),
    popularDishes,
    createdAt: String(row.created_at),
  };
}

function computeBudgetTier(priceMax: number): 'Budget' | 'Moderate' | 'Premium' {
  if (priceMax <= 180) return 'Budget';
  if (priceMax <= 450) return 'Moderate';
  return 'Premium';
}

function cityCoordinates(city: string): { lat: number; lng: number } {
  const match = VIDARBHA_CITIES.find((c) => c.name.toLowerCase() === city.toLowerCase());
  return match ? { lat: match.lat, lng: match.lng } : { lat: 21.1458, lng: 79.0882 };
}

// ---------- AUTH ROUTES ----------

app.get('/api/auth/status', (_req, res) => {
  const passcodeConfigured = Boolean(process.env.ADMIN_PASSCODE?.trim());
  res.json({
    adminClaimed: hasClaimedAdmin(),
    passcodeConfigured,
  });
});

app.post('/api/auth/register', (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (name.length < 2 || name.length > 80) {
    res.status(400).json({ error: 'Please enter a valid name (2-80 characters).' });
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    res.status(400).json({ error: 'Please enter a valid email address.' });
    return;
  }
  if (password.length < 6 || password.length > 100) {
    res.status(400).json({ error: 'Password must be between 6 and 100 characters.' });
    return;
  }

  const existing = db.prepare(`SELECT id FROM users WHERE email = ?`).get(email);
  if (existing) {
    res.status(409).json({ error: 'An account with this email already exists.' });
    return;
  }

  const passwordHash = hashPassword(password);
  const result = db
    .prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'user')`)
    .run(name, email, passwordHash);

  const uid = Number(result.lastInsertRowid);
  const userRow = db
    .prepare(`SELECT id, name, email, role, created_at FROM users WHERE id = ?`)
    .get(uid) as { id: number; name: string; email: string; role: 'user' | 'admin'; created_at: string };

  const token = signToken({ uid: userRow.id, email: userRow.email, role: userRow.role });
  res.status(201).json({
    token,
    user: {
      id: userRow.id,
      name: userRow.name,
      email: userRow.email,
      role: userRow.role,
      createdAt: userRow.created_at,
    },
    favoriteIds: [],
  });
});

app.post('/api/auth/login', (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required.' });
    return;
  }

  const row = db
    .prepare(`SELECT id, name, email, password_hash, role, created_at FROM users WHERE email = ?`)
    .get(email) as
    | {
        id: number;
        name: string;
        email: string;
        password_hash: string;
        role: 'user' | 'admin';
        created_at: string;
      }
    | undefined;

  if (!row || !verifyPassword(password, row.password_hash)) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const favRows = db
    .prepare(`SELECT listing_id FROM favorites WHERE user_id = ?`)
    .all(row.id) as { listing_id: number }[];

  const token = signToken({ uid: row.id, email: row.email, role: row.role });
  res.json({
    token,
    user: {
      id: row.id,
      name: row.name,
      email: row.email,
      role: row.role,
      createdAt: row.created_at,
    },
    favoriteIds: favRows.map((f) => Number(f.listing_id)),
  });
});

app.post('/api/auth/admin-claim', (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode : '';

  const envPasscode = process.env.ADMIN_PASSCODE?.trim();
  const alreadyClaimed = hasClaimedAdmin();

  if (envPasscode) {
    // When ADMIN_PASSCODE is configured in secrets, verify it safely in constant time
    const passBuf = Buffer.from(passcode);
    const envBuf = Buffer.from(envPasscode);
    if (passBuf.length !== envBuf.length || !crypto.timingSafeEqual(passBuf, envBuf)) {
      res.status(403).json({ error: 'Invalid administrator passcode.' });
      return;
    }
  } else if (alreadyClaimed) {
    res.status(403).json({
      error: 'Administrator access has already been claimed. Please sign in with your admin email and password.',
    });
    return;
  }

  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 6) {
    res.status(400).json({ error: 'Provide valid admin name, email, and a password (6+ characters).' });
    return;
  }

  const passwordHash = hashPassword(password);
  const existing = db.prepare(`SELECT id FROM users WHERE email = ?`).get(email) as { id: number } | undefined;

  let uid: number;
  if (existing) {
    db.prepare(`UPDATE users SET name = ?, password_hash = ?, role = 'admin' WHERE id = ?`).run(
      name,
      passwordHash,
      existing.id
    );
    uid = existing.id;
  } else {
    const insert = db
      .prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')`)
      .run(name, email, passwordHash);
    uid = Number(insert.lastInsertRowid);
  }

  const userRow = db
    .prepare(`SELECT id, name, email, role, created_at FROM users WHERE id = ?`)
    .get(uid) as { id: number; name: string; email: string; role: 'user' | 'admin'; created_at: string };

  const token = signToken({ uid: userRow.id, email: userRow.email, role: userRow.role });
  res.json({
    token,
    user: {
      id: userRow.id,
      name: userRow.name,
      email: userRow.email,
      role: userRow.role,
      createdAt: userRow.created_at,
    },
    favoriteIds: [],
  });
});

app.get('/api/auth/me', requireAuth, (req: AuthRequest, res) => {
  const favRows = db
    .prepare(`SELECT listing_id FROM favorites WHERE user_id = ?`)
    .all(req.user!.id) as { listing_id: number }[];
  res.json({
    user: req.user,
    favoriteIds: favRows.map((f) => Number(f.listing_id)),
  });
});

// ---------- PUBLIC DISCOVERY ROUTES ----------

app.get('/api/listings', (req, res) => {
  const city = typeof req.query.city === 'string' ? req.query.city.trim() : '';
  const category = typeof req.query.category === 'string' ? req.query.category.trim() : '';
  const budget = typeof req.query.budget === 'string' ? req.query.budget.trim() : '';
  const dietary = typeof req.query.dietary === 'string' ? req.query.dietary.trim() : '';
  const minRating = Number(req.query.minRating || 0);
  const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
  const flag = typeof req.query.flag === 'string' ? req.query.flag.trim() : '';

  const conditions: string[] = [];
  const params: unknown[] = [];

  if (city && city !== 'All') {
    conditions.push(`LOWER(city) = LOWER(?)`);
    params.push(city);
  }
  if (category && category !== 'All') {
    conditions.push(`LOWER(category) = LOWER(?)`);
    params.push(category);
  }
  if (budget && budget !== 'All') {
    conditions.push(`budget_tier = ?`);
    params.push(budget);
  }
  if (dietary && dietary !== 'All') {
    if (dietary === 'Veg') {
      conditions.push(`(dietary = 'Veg' OR dietary = 'Veg & Non-Veg')`);
    } else if (dietary === 'Non-Veg') {
      conditions.push(`(dietary = 'Non-Veg' OR dietary = 'Veg & Non-Veg')`);
    }
  }
  if (minRating > 0) {
    conditions.push(`rating >= ?`);
    params.push(minRating);
  }
  if (flag === 'trending') conditions.push(`is_trending = 1`);
  if (flag === 'hidden') conditions.push(`is_hidden_gem = 1`);
  if (flag === 'featured') conditions.push(`is_featured = 1`);

  if (search) {
    conditions.push(
      `(LOWER(name) LIKE ? OR LOWER(city) LIKE ? OR LOWER(speciality) LIKE ? OR LOWER(category) LIKE ? OR LOWER(popular_dishes) LIKE ? OR LOWER(address) LIKE ?)`
    );
    const pattern = `%${search}%`;
    params.push(pattern, pattern, pattern, pattern, pattern, pattern);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  const orderClause =
    flag === 'recent'
      ? `ORDER BY id DESC`
      : `ORDER BY is_featured DESC, is_trending DESC, rating DESC, id DESC`;

  const rows = db.prepare(`SELECT * FROM listings ${whereClause} ${orderClause}`).all(...params);
  res.json(rows.map((r) => mapListingRow(r)));
});

app.get('/api/listings/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid listing ID.' });
    return;
  }

  const row = db.prepare(`SELECT * FROM listings WHERE id = ?`).get(id);
  if (!row) {
    res.status(404).json({ error: 'Food listing not found.' });
    return;
  }

  const reviews = db
    .prepare(
      `SELECT id, listing_id, user_id, author_name, rating, comment, image_url, created_at
       FROM reviews WHERE listing_id = ? ORDER BY id DESC`
    )
    .all(id)
    .map((r) => ({
      id: Number(r.id),
      listingId: Number(r.listing_id),
      userId: r.user_id === null ? null : Number(r.user_id),
      authorName: String(r.author_name),
      rating: Number(r.rating),
      comment: String(r.comment),
      imageUrl: r.image_url ? String(r.image_url) : null,
      createdAt: String(r.created_at),
    }));

  res.json({ listing: mapListingRow(row), reviews });
});

app.get('/api/reviews/recent', (_req, res) => {
  const rows = db
    .prepare(
      `SELECT r.id, r.listing_id, r.user_id, r.author_name, r.rating, r.comment, r.image_url, r.created_at,
              l.name AS listing_name, l.city AS listing_city
       FROM reviews r
       INNER JOIN listings l ON l.id = r.listing_id
       ORDER BY r.id DESC
       LIMIT 8`
    )
    .all();

  res.json(
    rows.map((r) => ({
      id: Number(r.id),
      listingId: Number(r.listing_id),
      listingName: String(r.listing_name),
      listingCity: String(r.listing_city),
      userId: r.user_id === null ? null : Number(r.user_id),
      authorName: String(r.author_name),
      rating: Number(r.rating),
      comment: String(r.comment),
      imageUrl: r.image_url ? String(r.image_url) : null,
      createdAt: String(r.created_at),
    }))
  );
});

app.get('/api/stories', (_req, res) => {
  const rows = db.prepare(`SELECT * FROM stories ORDER BY id ASC`).all();
  res.json(
    rows.map((r) => ({
      id: Number(r.id),
      slug: String(r.slug),
      title: String(r.title),
      subtitle: String(r.subtitle),
      city: String(r.city),
      topic: String(r.topic),
      readTime: String(r.read_time),
      author: String(r.author),
      publishedAt: String(r.published_at),
      imageUrl: String(r.image_url),
      excerpt: String(r.excerpt),
      content: JSON.parse(String(r.content_json || '[]')),
      recipeHighlights: r.recipe_json ? JSON.parse(String(r.recipe_json)) : undefined,
    }))
  );
});

// ---------- USER AUTHENTICATED ROUTES ----------

app.post('/api/upload', requireAuth, (req, res) => {
  const dataUrl = typeof req.body?.dataUrl === 'string' ? req.body.dataUrl : '';
  const match = dataUrl.match(/^data:(image\/(?:jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) {
    res.status(400).json({ error: 'Only JPEG, PNG, or WebP images are supported.' });
    return;
  }

  const mime = match[1];
  const base64Body = match[2];
  const buffer = Buffer.from(base64Body, 'base64');

  if (buffer.length === 0 || buffer.length > 4 * 1024 * 1024) {
    res.status(400).json({ error: 'Image file must be under 4 MB.' });
    return;
  }

  const ext = mime === 'image/png' ? '.png' : mime === 'image/webp' ? '.webp' : '.jpg';
  const fileName = `food-${crypto.randomUUID()}${ext}`;
  const resolved = path.resolve(uploadsDir, fileName);

  if (!resolved.startsWith(uploadsDir + path.sep)) {
    res.status(400).json({ error: 'Invalid upload path.' });
    return;
  }

  fs.writeFileSync(resolved, buffer);
  res.status(201).json({ imageUrl: `/uploads/${fileName}` });
});

app.get('/api/favorites', requireAuth, (req: AuthRequest, res) => {
  const rows = db
    .prepare(
      `SELECT l.* FROM listings l
       INNER JOIN favorites f ON f.listing_id = l.id
       WHERE f.user_id = ?
       ORDER BY f.id DESC`
    )
    .all(req.user!.id);
  res.json(rows.map((r) => mapListingRow(r)));
});

app.post('/api/favorites/:listingId', requireAuth, (req: AuthRequest, res) => {
  const listingId = Number(req.params.listingId);
  if (!Number.isInteger(listingId) || listingId <= 0) {
    res.status(400).json({ error: 'Invalid listing ID.' });
    return;
  }

  const exists = db.prepare(`SELECT id FROM listings WHERE id = ?`).get(listingId);
  if (!exists) {
    res.status(404).json({ error: 'Listing not found.' });
    return;
  }

  const existingFav = db
    .prepare(`SELECT id FROM favorites WHERE user_id = ? AND listing_id = ?`)
    .get(req.user!.id, listingId) as { id: number } | undefined;

  let saved = false;
  if (existingFav) {
    db.prepare(`DELETE FROM favorites WHERE id = ?`).run(existingFav.id);
    saved = false;
  } else {
    db.prepare(`INSERT INTO favorites (user_id, listing_id) VALUES (?, ?)`).run(
      req.user!.id,
      listingId
    );
    saved = true;
  }

  const favRows = db
    .prepare(`SELECT listing_id FROM favorites WHERE user_id = ?`)
    .all(req.user!.id) as { listing_id: number }[];

  res.json({ saved, favoriteIds: favRows.map((f) => Number(f.listing_id)) });
});

app.post('/api/listings/:id/reviews', requireAuth, (req: AuthRequest, res) => {
  const listingId = Number(req.params.id);
  if (!Number.isInteger(listingId) || listingId <= 0) {
    res.status(400).json({ error: 'Invalid listing ID.' });
    return;
  }

  const listing = db.prepare(`SELECT id FROM listings WHERE id = ?`).get(listingId);
  if (!listing) {
    res.status(404).json({ error: 'Listing not found.' });
    return;
  }

  const rating = Number(req.body?.rating);
  const comment = typeof req.body?.comment === 'string' ? req.body.comment.trim() : '';
  const imageUrlRaw = typeof req.body?.imageUrl === 'string' ? req.body.imageUrl.trim() : '';

  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    res.status(400).json({ error: 'Rating must be between 1 and 5 stars.' });
    return;
  }
  if (comment.length < 5 || comment.length > 800) {
    res.status(400).json({ error: 'Review comment must be between 5 and 800 characters.' });
    return;
  }

  const cleanImg = imageUrlRaw ? safeImageUrl(imageUrlRaw, '') : '';
  const insert = db
    .prepare(
      `INSERT INTO reviews (listing_id, user_id, author_name, rating, comment, image_url)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(listingId, req.user!.id, req.user!.name, rating, comment, cleanImg || null);

  recomputeListingRating(listingId);

  const updatedListing = db.prepare(`SELECT * FROM listings WHERE id = ?`).get(listingId)!;
  const createdReview = db
    .prepare(`SELECT * FROM reviews WHERE id = ?`)
    .get(Number(insert.lastInsertRowid))!;

  res.status(201).json({
    review: {
      id: Number(createdReview.id),
      listingId: Number(createdReview.listing_id),
      userId: Number(createdReview.user_id),
      authorName: String(createdReview.author_name),
      rating: Number(createdReview.rating),
      comment: String(createdReview.comment),
      imageUrl: createdReview.image_url ? String(createdReview.image_url) : null,
      createdAt: String(createdReview.created_at),
    },
    listing: mapListingRow(updatedListing),
  });
});

app.post('/api/submissions', requireAuth, (req: AuthRequest, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const city = typeof req.body?.city === 'string' ? req.body.city.trim() : '';
  const category = typeof req.body?.category === 'string' ? req.body.category.trim() : '';
  const speciality = typeof req.body?.speciality === 'string' ? req.body.speciality.trim() : '';
  const description = typeof req.body?.description === 'string' ? req.body.description.trim() : '';
  const address = typeof req.body?.address === 'string' ? req.body.address.trim() : '';
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : 'Not listed';
  const openingHours =
    typeof req.body?.openingHours === 'string' ? req.body.openingHours.trim() : '9:00 AM – 10:00 PM';
  const priceMin = Math.max(10, Number(req.body?.priceMin || 60));
  const priceMax = Math.max(priceMin, Number(req.body?.priceMax || 220));
  const dietary =
    req.body?.dietary === 'Non-Veg' || req.body?.dietary === 'Veg & Non-Veg'
      ? req.body.dietary
      : 'Veg';
  const isHiddenGem = req.body?.isHiddenGem ? 1 : 0;
  const imageUrl = safeImageUrl(req.body?.imageUrl);

  if (name.length < 3 || !city || !category || speciality.length < 4 || address.length < 5) {
    res.status(400).json({ error: 'Please complete all required food place fields.' });
    return;
  }

  const insert = db
    .prepare(
      `INSERT INTO submissions (
        user_id, submitter_name, submitter_email, name, city, category, speciality,
        description, address, phone, opening_hours, price_min, price_max, dietary,
        is_hidden_gem, image_url, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`
    )
    .run(
      req.user!.id,
      req.user!.name,
      req.user!.email,
      name,
      city,
      category,
      speciality,
      description || speciality,
      address,
      phone,
      openingHours,
      priceMin,
      priceMax,
      dietary,
      isHiddenGem,
      imageUrl
    );

  const row = db
    .prepare(`SELECT * FROM submissions WHERE id = ?`)
    .get(Number(insert.lastInsertRowid))!;

  res.status(201).json({
    id: Number(row.id),
    name: String(row.name),
    city: String(row.city),
    status: String(row.status),
  });
});

app.get('/api/submissions/mine', requireAuth, (req: AuthRequest, res) => {
  const rows = db
    .prepare(`SELECT * FROM submissions WHERE user_id = ? ORDER BY id DESC`)
    .all(req.user!.id);

  res.json(
    rows.map((r) => ({
      id: Number(r.id),
      userId: r.user_id === null ? null : Number(r.user_id),
      submitterName: String(r.submitter_name),
      submitterEmail: String(r.submitter_email),
      name: String(r.name),
      city: String(r.city),
      category: String(r.category),
      speciality: String(r.speciality),
      description: String(r.description),
      address: String(r.address),
      phone: String(r.phone),
      openingHours: String(r.opening_hours),
      priceMin: Number(r.price_min),
      priceMax: Number(r.price_max),
      dietary: String(r.dietary),
      isHiddenGem: Boolean(r.is_hidden_gem),
      imageUrl: String(r.image_url),
      status: String(r.status),
      adminNote: r.admin_note ? String(r.admin_note) : null,
      createdAt: String(r.created_at),
    }))
  );
});

// ---------- ADMIN DASHBOARD ROUTES ----------

app.get('/api/admin/overview', requireAdmin, (_req, res) => {
  const listingsRows = db.prepare(`SELECT * FROM listings ORDER BY id DESC`).all();
  const submissionsRows = db.prepare(`SELECT * FROM submissions ORDER BY id DESC`).all();
  const reviewsRows = db
    .prepare(
      `SELECT r.*, l.name AS listing_name, l.city AS listing_city
       FROM reviews r
       INNER JOIN listings l ON l.id = r.listing_id
       ORDER BY r.id DESC`
    )
    .all();

  const userCountRow = db.prepare(`SELECT COUNT(*) AS cnt FROM users`).get() as { cnt: number };
  const verifiedRow = db
    .prepare(`SELECT COUNT(*) AS cnt FROM listings WHERE is_verified = 1`)
    .get() as { cnt: number };
  const pendingRow = db
    .prepare(`SELECT COUNT(*) AS cnt FROM submissions WHERE status = 'pending'`)
    .get() as { cnt: number };
  const citiesRow = db
    .prepare(`SELECT COUNT(DISTINCT city) AS cnt FROM listings`)
    .get() as { cnt: number };

  const totalListings = listingsRows.length;
  const verifiedListings = Number(verifiedRow.cnt);

  res.json({
    stats: {
      totalListings,
      verifiedListings,
      demoListings: totalListings - verifiedListings,
      pendingSubmissions: Number(pendingRow.cnt),
      totalReviews: reviewsRows.length,
      totalUsers: Number(userCountRow.cnt),
      citiesCovered: Number(citiesRow.cnt),
    },
    listings: listingsRows.map((r) => mapListingRow(r)),
    submissions: submissionsRows.map((r) => ({
      id: Number(r.id),
      userId: r.user_id === null ? null : Number(r.user_id),
      submitterName: String(r.submitter_name),
      submitterEmail: String(r.submitter_email),
      name: String(r.name),
      city: String(r.city),
      category: String(r.category),
      speciality: String(r.speciality),
      description: String(r.description),
      address: String(r.address),
      phone: String(r.phone),
      openingHours: String(r.opening_hours),
      priceMin: Number(r.price_min),
      priceMax: Number(r.price_max),
      dietary: String(r.dietary),
      isHiddenGem: Boolean(r.is_hidden_gem),
      imageUrl: String(r.image_url),
      status: String(r.status),
      adminNote: r.admin_note ? String(r.admin_note) : null,
      createdAt: String(r.created_at),
    })),
    reviews: reviewsRows.map((r) => ({
      id: Number(r.id),
      listingId: Number(r.listing_id),
      listingName: String(r.listing_name),
      listingCity: String(r.listing_city),
      userId: r.user_id === null ? null : Number(r.user_id),
      authorName: String(r.author_name),
      rating: Number(r.rating),
      comment: String(r.comment),
      imageUrl: r.image_url ? String(r.image_url) : null,
      createdAt: String(r.created_at),
    })),
  });
});

app.post('/api/admin/listings', requireAdmin, (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const city = typeof req.body?.city === 'string' ? req.body.city.trim() : '';
  const category = typeof req.body?.category === 'string' ? req.body.category.trim() : '';
  const speciality = typeof req.body?.speciality === 'string' ? req.body.speciality.trim() : '';
  const description = typeof req.body?.description === 'string' ? req.body.description.trim() : '';
  const address = typeof req.body?.address === 'string' ? req.body.address.trim() : '';
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : '+91 00000 00000';
  const openingHours =
    typeof req.body?.openingHours === 'string' ? req.body.openingHours.trim() : '9:00 AM – 10:00 PM';
  const priceMin = Math.max(10, Number(req.body?.priceMin || 50));
  const priceMax = Math.max(priceMin, Number(req.body?.priceMax || 250));
  const dietary =
    req.body?.dietary === 'Non-Veg' || req.body?.dietary === 'Veg & Non-Veg'
      ? req.body.dietary
      : 'Veg';
  const isVerified = req.body?.isVerified ? 1 : 0;
  const isTrending = req.body?.isTrending ? 1 : 0;
  const isHiddenGem = req.body?.isHiddenGem ? 1 : 0;
  const isFeatured = req.body?.isFeatured ? 1 : 0;
  const imageUrl = safeImageUrl(req.body?.imageUrl);
  const popularDishes = Array.isArray(req.body?.popularDishes)
    ? req.body.popularDishes.filter((d: unknown) => typeof d === 'string' && d.trim()).slice(0, 6)
    : [speciality];

  if (name.length < 3 || !city || !category || !speciality || !address) {
    res.status(400).json({ error: 'Name, city, category, speciality, and address are required.' });
    return;
  }

  const coords = cityCoordinates(city);
  const insert = db
    .prepare(
      `INSERT INTO listings (
        name, slug, city, category, speciality, description, address, phone,
        opening_hours, price_min, price_max, budget_tier, dietary, rating, review_count,
        image_url, lat, lng, is_verified, is_trending, is_hidden_gem, is_featured, popular_dishes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 4.5, 0, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      name,
      slugify(name),
      city,
      category,
      speciality,
      description || speciality,
      address,
      phone,
      openingHours,
      priceMin,
      priceMax,
      computeBudgetTier(priceMax),
      dietary,
      imageUrl,
      coords.lat,
      coords.lng,
      isVerified,
      isTrending,
      isHiddenGem,
      isFeatured,
      JSON.stringify(popularDishes)
    );

  const row = db.prepare(`SELECT * FROM listings WHERE id = ?`).get(Number(insert.lastInsertRowid))!;
  res.status(201).json(mapListingRow(row));
});

app.patch('/api/admin/listings/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT * FROM listings WHERE id = ?`).get(id);
  if (!existing) {
    res.status(404).json({ error: 'Listing not found.' });
    return;
  }

  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : String(existing.name);
  const city = typeof req.body?.city === 'string' ? req.body.city.trim() : String(existing.city);
  const category =
    typeof req.body?.category === 'string' ? req.body.category.trim() : String(existing.category);
  const speciality =
    typeof req.body?.speciality === 'string'
      ? req.body.speciality.trim()
      : String(existing.speciality);
  const description =
    typeof req.body?.description === 'string'
      ? req.body.description.trim()
      : String(existing.description);
  const address =
    typeof req.body?.address === 'string' ? req.body.address.trim() : String(existing.address);
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : String(existing.phone);
  const openingHours =
    typeof req.body?.openingHours === 'string'
      ? req.body.openingHours.trim()
      : String(existing.opening_hours);
  const priceMin =
    req.body?.priceMin !== undefined ? Math.max(10, Number(req.body.priceMin)) : Number(existing.price_min);
  const priceMax =
    req.body?.priceMax !== undefined
      ? Math.max(priceMin, Number(req.body.priceMax))
      : Number(existing.price_max);
  const dietary =
    req.body?.dietary === 'Veg' ||
    req.body?.dietary === 'Non-Veg' ||
    req.body?.dietary === 'Veg & Non-Veg'
      ? req.body.dietary
      : String(existing.dietary);
  const imageUrl =
    req.body?.imageUrl !== undefined
      ? safeImageUrl(req.body.imageUrl, String(existing.image_url))
      : String(existing.image_url);
  const isVerified =
    req.body?.isVerified !== undefined ? (req.body.isVerified ? 1 : 0) : Number(existing.is_verified);
  const isTrending =
    req.body?.isTrending !== undefined ? (req.body.isTrending ? 1 : 0) : Number(existing.is_trending);
  const isHiddenGem =
    req.body?.isHiddenGem !== undefined
      ? req.body.isHiddenGem
        ? 1
        : 0
      : Number(existing.is_hidden_gem);
  const isFeatured =
    req.body?.isFeatured !== undefined ? (req.body.isFeatured ? 1 : 0) : Number(existing.is_featured);

  db.prepare(
    `UPDATE listings SET
      name = ?, city = ?, category = ?, speciality = ?, description = ?, address = ?, phone = ?,
      opening_hours = ?, price_min = ?, price_max = ?, budget_tier = ?, dietary = ?,
      image_url = ?, is_verified = ?, is_trending = ?, is_hidden_gem = ?, is_featured = ?
     WHERE id = ?`
  ).run(
    name,
    city,
    category,
    speciality,
    description,
    address,
    phone,
    openingHours,
    priceMin,
    priceMax,
    computeBudgetTier(priceMax),
    dietary,
    imageUrl,
    isVerified,
    isTrending,
    isHiddenGem,
    isFeatured,
    id
  );

  const updated = db.prepare(`SELECT * FROM listings WHERE id = ?`).get(id)!;
  res.json(mapListingRow(updated));
});

app.delete('/api/admin/listings/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const resDel = db.prepare(`DELETE FROM listings WHERE id = ?`).run(id);
  if (resDel.changes === 0) {
    res.status(404).json({ error: 'Listing not found.' });
    return;
  }
  res.json({ deleted: true });
});

app.patch('/api/admin/submissions/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const sub = db.prepare(`SELECT * FROM submissions WHERE id = ?`).get(id);
  if (!sub) {
    res.status(404).json({ error: 'Submission not found.' });
    return;
  }

  const action = req.body?.status === 'approved' ? 'approved' : 'rejected';
  const adminNote = typeof req.body?.adminNote === 'string' ? req.body.adminNote.trim() : null;

  if (sub.status === 'pending' && action === 'approved') {
    const coords = cityCoordinates(String(sub.city));
    const priceMax = Number(sub.price_max);
    db.prepare(
      `INSERT INTO listings (
        name, slug, city, category, speciality, description, address, phone,
        opening_hours, price_min, price_max, budget_tier, dietary, rating, review_count,
        image_url, lat, lng, is_verified, is_trending, is_hidden_gem, is_featured, popular_dishes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 4.6, 0, ?, ?, ?, 1, 0, ?, 0, ?)`
    ).run(
      String(sub.name),
      slugify(String(sub.name)),
      String(sub.city),
      String(sub.category),
      String(sub.speciality),
      String(sub.description),
      String(sub.address),
      String(sub.phone),
      String(sub.opening_hours),
      Number(sub.price_min),
      priceMax,
      computeBudgetTier(priceMax),
      String(sub.dietary),
      String(sub.image_url),
      coords.lat,
      coords.lng,
      Number(sub.is_hidden_gem),
      JSON.stringify([String(sub.speciality)])
    );
  }

  db.prepare(`UPDATE submissions SET status = ?, admin_note = ? WHERE id = ?`).run(
    action,
    adminNote,
    id
  );
  res.json({ id, status: action });
});

app.delete('/api/admin/reviews/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const rev = db.prepare(`SELECT listing_id FROM reviews WHERE id = ?`).get(id) as
    | { listing_id: number }
    | undefined;
  if (!rev) {
    res.status(404).json({ error: 'Review not found.' });
    return;
  }
  db.prepare(`DELETE FROM reviews WHERE id = ?`).run(id);
  recomputeListingRating(Number(rev.listing_id));
  res.json({ deleted: true });
});

// Touch optional auth helper so unused import isn't flagged
void extractAuthUser;

// ---------- VITE / STATIC SERVER ----------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TarriTrail server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
